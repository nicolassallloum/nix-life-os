--
-- PostgreSQL database dump
--

\restrict uF9N8XyiTwnqAJX5ZxPB2u2rgNcEedvyumKeZrK5l8nNISbKpCAK0KlJ45t9O38

-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ai; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA ai;


--
-- Name: automation; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA automation;


--
-- Name: finance; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA finance;


--
-- Name: health; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA health;


--
-- Name: monitoring; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA monitoring;


--
-- Name: nix_life_os; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA nix_life_os;


--
-- Name: projects; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA projects;


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_user; Type: TABLE; Schema: nix_life_os; Owner: -
--

CREATE TABLE nix_life_os.app_user (
    user_id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    username text,
    password_hash text NOT NULL,
    full_name character varying(150) NOT NULL,
    phone_number character varying(30),
    timezone character varying(100) DEFAULT 'Asia/Beirut'::character varying NOT NULL,
    locale character varying(20) DEFAULT 'en'::character varying NOT NULL,
    currency_code character(3) DEFAULT 'USD'::bpchar NOT NULL,
    date_of_birth date,
    gender character varying(30),
    profile_image_url text,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    email_verified_at timestamp with time zone,
    last_login_at timestamp with time zone,
    preferences_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_active boolean,
    CONSTRAINT app_user_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text, ('locked'::character varying)::text, ('deleted'::character varying)::text])))
);


--
-- Name: finance_account; Type: TABLE; Schema: nix_life_os; Owner: -
--

CREATE TABLE nix_life_os.finance_account (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    account_name character varying(255) NOT NULL,
    account_type character varying(100) DEFAULT 'cash'::character varying NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying NOT NULL,
    initial_balance numeric(15,2) DEFAULT 0 NOT NULL,
    current_balance numeric(15,2) DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: finance_budget; Type: TABLE; Schema: nix_life_os; Owner: -
--

CREATE TABLE nix_life_os.finance_budget (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    category_id uuid,
    budget_name character varying(255) NOT NULL,
    budget_month character varying(7),
    amount numeric(15,2) DEFAULT 0 NOT NULL,
    spent_amount numeric(15,2) DEFAULT 0 NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: finance_category; Type: TABLE; Schema: nix_life_os; Owner: -
--

CREATE TABLE nix_life_os.finance_category (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    category_name character varying(255) NOT NULL,
    category_type character varying(50) DEFAULT 'expense'::character varying NOT NULL,
    color character varying(50),
    icon character varying(100),
    is_active boolean DEFAULT true NOT NULL,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: finance_transaction; Type: TABLE; Schema: nix_life_os; Owner: -
--

CREATE TABLE nix_life_os.finance_transaction (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    account_id uuid,
    category_id uuid,
    transaction_type character varying(50) DEFAULT 'expense'::character varying NOT NULL,
    amount numeric(15,2) DEFAULT 0 NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying NOT NULL,
    description text,
    transaction_date date DEFAULT CURRENT_DATE NOT NULL,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: health_meal_log; Type: TABLE; Schema: nix_life_os; Owner: -
--

CREATE TABLE nix_life_os.health_meal_log (
    meal_log_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    meal_type character varying(20) NOT NULL,
    consumed_at timestamp with time zone NOT NULL,
    notes text,
    total_calories numeric(10,2),
    totals_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    meal_date date,
    CONSTRAINT health_meal_log_meal_type_check CHECK (((meal_type)::text = ANY (ARRAY[('breakfast'::character varying)::text, ('lunch'::character varying)::text, ('dinner'::character varying)::text, ('snack'::character varying)::text, ('other'::character varying)::text])))
);


--
-- Name: health_step_log; Type: TABLE; Schema: nix_life_os; Owner: -
--

CREATE TABLE nix_life_os.health_step_log (
    step_log_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    log_date date NOT NULL,
    steps_count integer NOT NULL,
    distance_km numeric(8,3),
    calories_burned numeric(8,2),
    source character varying(30) DEFAULT 'manual'::character varying,
    source_payload_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT health_step_log_steps_count_check CHECK ((steps_count >= 0))
);


--
-- Name: ai_alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_alerts (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    alert_type character varying(80) NOT NULL,
    module character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    severity character varying(30) DEFAULT 'warning'::character varying NOT NULL,
    risk_score numeric(8,2),
    trigger_data jsonb,
    alert_date date NOT NULL,
    is_resolved boolean DEFAULT false NOT NULL,
    resolved_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: ai_insights; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_insights (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    insight_type character varying(50) NOT NULL,
    category character varying(100),
    title character varying(255) NOT NULL,
    message text NOT NULL,
    severity character varying(30) DEFAULT 'info'::character varying NOT NULL,
    score numeric(8,2),
    metadata jsonb,
    insight_date date NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    is_archived boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: ai_predictions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_predictions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    prediction_type character varying(255) NOT NULL,
    prediction_date date NOT NULL,
    target_date date,
    current_value numeric(14,2),
    predicted_value numeric(14,2),
    change_value numeric(14,2),
    change_percentage numeric(8,2),
    input_summary jsonb,
    prediction_payload jsonb,
    confidence_level character varying(255) DEFAULT 'medium'::character varying NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: ai_recommendation_feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_recommendation_feedback (
    id uuid NOT NULL,
    recommendation_id uuid NOT NULL,
    user_id uuid NOT NULL,
    feedback_type character varying(50) NOT NULL,
    feedback_value smallint,
    feedback_comment text,
    metadata jsonb,
    created_at timestamp(0) with time zone,
    updated_at timestamp(0) with time zone,
    deleted_at timestamp(0) with time zone,
    CONSTRAINT chk_ai_feedback_type CHECK (((feedback_type)::text = ANY ((ARRAY['useful'::character varying, 'not_useful'::character varying, 'too_late'::character varying, 'not_relevant'::character varying, 'accepted'::character varying, 'dismissed'::character varying, 'completed'::character varying, 'rating'::character varying])::text[]))),
    CONSTRAINT chk_ai_feedback_value CHECK (((feedback_value IS NULL) OR ((feedback_value >= 1) AND (feedback_value <= 5))))
);


--
-- Name: ai_recommendation_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_recommendation_rules (
    id uuid NOT NULL,
    rule_code character varying(100) NOT NULL,
    rule_name character varying(255) NOT NULL,
    module character varying(50) NOT NULL,
    recommendation_type character varying(100) NOT NULL,
    condition_key character varying(150),
    operator character varying(30),
    threshold_value numeric(14,4),
    condition_payload jsonb,
    severity character varying(50) DEFAULT 'medium'::character varying NOT NULL,
    priority smallint DEFAULT '3'::smallint NOT NULL,
    title_template character varying(255) NOT NULL,
    message_template text NOT NULL,
    action_template text,
    base_confidence_score numeric(5,2) DEFAULT '70'::numeric NOT NULL,
    base_impact_score numeric(5,2) DEFAULT '50'::numeric NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    valid_from timestamp(0) with time zone,
    valid_to timestamp(0) with time zone,
    metadata jsonb,
    created_at timestamp(0) with time zone,
    updated_at timestamp(0) with time zone,
    deleted_at timestamp(0) with time zone,
    CONSTRAINT chk_ai_rules_base_confidence CHECK (((base_confidence_score >= (0)::numeric) AND (base_confidence_score <= (100)::numeric))),
    CONSTRAINT chk_ai_rules_base_impact CHECK (((base_impact_score >= (0)::numeric) AND (base_impact_score <= (100)::numeric))),
    CONSTRAINT chk_ai_rules_module CHECK (((module)::text = ANY ((ARRAY['finance'::character varying, 'health'::character varying, 'productivity'::character varying, 'life_balance'::character varying, 'goals'::character varying, 'habits'::character varying, 'system'::character varying])::text[]))),
    CONSTRAINT chk_ai_rules_operator CHECK (((operator IS NULL) OR ((operator)::text = ANY ((ARRAY['>'::character varying, '>='::character varying, '<'::character varying, '<='::character varying, '='::character varying, '!='::character varying, 'between'::character varying, 'not_between'::character varying, 'contains'::character varying, 'not_contains'::character varying, 'exists'::character varying, 'not_exists'::character varying])::text[])))),
    CONSTRAINT chk_ai_rules_priority CHECK (((priority >= 1) AND (priority <= 5))),
    CONSTRAINT chk_ai_rules_severity CHECK (((severity)::text = ANY ((ARRAY['critical'::character varying, 'high'::character varying, 'medium'::character varying, 'low'::character varying, 'positive'::character varying, 'info'::character varying])::text[])))
);


--
-- Name: ai_recommendations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_recommendations (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    rule_id uuid,
    module character varying(50) NOT NULL,
    recommendation_type character varying(100) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    action_text text,
    severity character varying(50) DEFAULT 'medium'::character varying NOT NULL,
    priority smallint DEFAULT '3'::smallint NOT NULL,
    confidence_score numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    impact_score numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    period_key character varying(50),
    duplicate_key character varying(255),
    source_data jsonb,
    score_breakdown jsonb,
    metadata jsonb,
    generated_at timestamp(0) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    viewed_at timestamp(0) with time zone,
    accepted_at timestamp(0) with time zone,
    dismissed_at timestamp(0) with time zone,
    completed_at timestamp(0) with time zone,
    expired_at timestamp(0) with time zone,
    expires_at timestamp(0) with time zone,
    created_at timestamp(0) with time zone,
    updated_at timestamp(0) with time zone,
    deleted_at timestamp(0) with time zone,
    CONSTRAINT chk_ai_recommendations_confidence CHECK (((confidence_score >= (0)::numeric) AND (confidence_score <= (100)::numeric))),
    CONSTRAINT chk_ai_recommendations_impact CHECK (((impact_score >= (0)::numeric) AND (impact_score <= (100)::numeric))),
    CONSTRAINT chk_ai_recommendations_module CHECK (((module)::text = ANY ((ARRAY['finance'::character varying, 'health'::character varying, 'productivity'::character varying, 'life_balance'::character varying, 'goals'::character varying, 'habits'::character varying, 'system'::character varying])::text[]))),
    CONSTRAINT chk_ai_recommendations_priority CHECK (((priority >= 1) AND (priority <= 5))),
    CONSTRAINT chk_ai_recommendations_severity CHECK (((severity)::text = ANY ((ARRAY['critical'::character varying, 'high'::character varying, 'medium'::character varying, 'low'::character varying, 'positive'::character varying, 'info'::character varying])::text[]))),
    CONSTRAINT chk_ai_recommendations_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'viewed'::character varying, 'accepted'::character varying, 'dismissed'::character varying, 'completed'::character varying, 'expired'::character varying])::text[])))
);


--
-- Name: ai_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_reports (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    report_type character varying(50) NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    title character varying(255) NOT NULL,
    summary text,
    finance_summary jsonb,
    health_summary jsonb,
    project_summary jsonb,
    recommendations jsonb,
    raw_metrics jsonb,
    overall_score numeric(8,2),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: ai_user_daily_scores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_user_daily_scores (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    score_date date NOT NULL,
    finance_score numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    health_score numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    productivity_score numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    goals_score numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    habits_score numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    life_balance_score numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    classification character varying(50),
    score_breakdown jsonb,
    source_summary jsonb,
    metadata jsonb,
    created_at timestamp(0) with time zone,
    updated_at timestamp(0) with time zone,
    deleted_at timestamp(0) with time zone,
    CONSTRAINT chk_ai_daily_scores_classification CHECK (((classification IS NULL) OR ((classification)::text = ANY ((ARRAY['excellent'::character varying, 'good'::character varying, 'needs_attention'::character varying, 'risk'::character varying, 'critical'::character varying])::text[])))),
    CONSTRAINT chk_ai_daily_scores_finance CHECK (((finance_score >= (0)::numeric) AND (finance_score <= (100)::numeric))),
    CONSTRAINT chk_ai_daily_scores_goals CHECK (((goals_score >= (0)::numeric) AND (goals_score <= (100)::numeric))),
    CONSTRAINT chk_ai_daily_scores_habits CHECK (((habits_score >= (0)::numeric) AND (habits_score <= (100)::numeric))),
    CONSTRAINT chk_ai_daily_scores_health CHECK (((health_score >= (0)::numeric) AND (health_score <= (100)::numeric))),
    CONSTRAINT chk_ai_daily_scores_life_balance CHECK (((life_balance_score >= (0)::numeric) AND (life_balance_score <= (100)::numeric))),
    CONSTRAINT chk_ai_daily_scores_productivity CHECK (((productivity_score >= (0)::numeric) AND (productivity_score <= (100)::numeric)))
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    module character varying(255),
    action character varying(255) NOT NULL,
    entity_type character varying(255),
    entity_id uuid,
    old_values jsonb,
    new_values jsonb,
    metadata jsonb,
    ip_address character varying(255),
    user_agent character varying(255),
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: automation_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_rules (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    rule_name character varying(255) NOT NULL,
    module character varying(255) NOT NULL,
    trigger_type character varying(255) NOT NULL,
    conditions jsonb,
    action_type character varying(255) DEFAULT 'create_notification'::character varying NOT NULL,
    action_payload jsonb,
    is_active boolean DEFAULT true NOT NULL,
    last_triggered_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: automation_trigger_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_trigger_logs (
    id uuid NOT NULL,
    automation_rule_id uuid NOT NULL,
    user_id uuid NOT NULL,
    status character varying(255) DEFAULT 'triggered'::character varying NOT NULL,
    evaluated_data jsonb,
    message text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration bigint NOT NULL
);


--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration bigint NOT NULL
);


--
-- Name: calorie_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calorie_entries (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: calorie_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.calorie_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: calorie_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.calorie_entries_id_seq OWNED BY public.calorie_entries.id;


--
-- Name: error_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.error_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    level character varying(255) DEFAULT 'error'::character varying NOT NULL,
    module character varying(255),
    exception_class character varying(255),
    message text NOT NULL,
    file text,
    line integer,
    request_method character varying(255),
    request_url text,
    request_payload jsonb,
    metadata jsonb,
    trace text,
    ip_address character varying(255),
    user_agent character varying(255),
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.expenses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: finance_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.finance_accounts (
    id uuid NOT NULL,
    user_id uuid,
    account_name character varying(255) NOT NULL,
    account_type character varying(50) NOT NULL,
    currency_code character varying(10) DEFAULT 'USD'::character varying NOT NULL,
    opening_balance numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    current_balance numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    description text
);


--
-- Name: finance_budget_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.finance_budget_lines (
    id uuid NOT NULL,
    budget_id uuid NOT NULL,
    user_id uuid,
    account_id uuid,
    category_id uuid,
    category character varying(255),
    planned_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    actual_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    spent_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    warning_percentage numeric(5,2) DEFAULT '80'::numeric NOT NULL,
    exceeded_percentage numeric(5,2) DEFAULT '100'::numeric NOT NULL,
    line_notes text,
    metadata_json json
);


--
-- Name: finance_budgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.finance_budgets (
    id uuid NOT NULL,
    user_id uuid,
    budget_name character varying(255) NOT NULL,
    category character varying(255),
    budget_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    spent_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    budget_month character varying(20) NOT NULL,
    currency_code character varying(10) DEFAULT 'USD'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    metadata_json json
);


--
-- Name: finance_core_tables; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.finance_core_tables (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: finance_core_tables_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.finance_core_tables_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: finance_core_tables_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.finance_core_tables_id_seq OWNED BY public.finance_core_tables.id;


--
-- Name: finance_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.finance_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    account_id uuid,
    transaction_type character varying(50) NOT NULL,
    category character varying(255),
    amount numeric(15,2) NOT NULL,
    currency_code character varying(10) DEFAULT 'USD'::character varying NOT NULL,
    transaction_date date,
    description character varying(255),
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    transfer_account_id uuid,
    category_id uuid,
    reference_no character varying(255),
    metadata_json json
);


--
-- Name: health_alert_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_alert_rules (
    id uuid NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    category character varying(100) NOT NULL,
    severity character varying(50) DEFAULT 'warning'::character varying NOT NULL,
    warning_threshold numeric(12,2),
    critical_threshold numeric(12,2),
    operator character varying(20),
    unit character varying(50),
    is_active boolean DEFAULT true NOT NULL,
    metadata json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: health_alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_alerts (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    alert_type character varying(100) NOT NULL,
    category character varying(100) NOT NULL,
    severity character varying(50) DEFAULT 'warning'::character varying NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    title character varying(255) NOT NULL,
    message text,
    alert_date date,
    source_table character varying(255),
    source_id uuid,
    metadata json,
    read_at timestamp(0) without time zone,
    resolved_at timestamp(0) without time zone,
    dismissed_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: health_food_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_food_items (
    id uuid NOT NULL,
    user_id uuid,
    food_name character varying(255) NOT NULL,
    brand_name character varying(255),
    category character varying(255),
    calories_per_100g numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    protein_per_100g numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    carbs_per_100g numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    fat_per_100g numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    sodium_per_100g_mg numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    potassium_per_100g_mg numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    phosphorus_per_100g_mg numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    is_ckd_friendly boolean DEFAULT false NOT NULL,
    is_custom boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: health_hydration_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_hydration_logs (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    log_date date NOT NULL,
    log_time time(0) without time zone,
    drink_type character varying(50) DEFAULT 'water'::character varying NOT NULL,
    amount_ml numeric(8,2) NOT NULL,
    is_ckd_safe boolean DEFAULT true NOT NULL,
    source character varying(50) DEFAULT 'manual'::character varying NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: health_lab_tests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_lab_tests (
    id bigint NOT NULL,
    user_id uuid,
    test_date date,
    test_name character varying(255) NOT NULL,
    result_value character varying(255),
    unit character varying(255),
    reference_range character varying(255),
    lab_name character varying(255),
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    category character varying(255),
    doctor_notes text,
    is_abnormal boolean DEFAULT false NOT NULL,
    abnormal_reason text,
    comparison_status character varying(50),
    previous_result_id bigint,
    creatinine numeric(8,2),
    urea numeric(8,2),
    egfr numeric(8,2),
    hemoglobin numeric(8,2),
    sodium numeric(8,2),
    potassium numeric(8,2),
    phosphorus numeric(8,2),
    source_type character varying(50) DEFAULT 'manual'::character varying NOT NULL,
    attachment_path character varying(255),
    status character varying(255) DEFAULT 'normal'::character varying NOT NULL
);


--
-- Name: health_lab_tests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.health_lab_tests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: health_lab_tests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.health_lab_tests_id_seq OWNED BY public.health_lab_tests.id;


--
-- Name: health_meal_log_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_meal_log_items (
    id uuid NOT NULL,
    meal_log_id uuid NOT NULL,
    food_item_id uuid NOT NULL,
    quantity_g numeric(10,2) NOT NULL,
    calories numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    protein_g numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    carbs_g numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    fat_g numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    sodium_mg numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    potassium_mg numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    phosphorus_mg numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: health_meal_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_meal_logs (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    meal_date date NOT NULL,
    meal_type character varying(255) NOT NULL,
    meal_name character varying(255),
    notes text,
    total_calories numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    total_protein_g numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    total_carbs_g numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    total_fat_g numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    total_sodium_mg numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    total_potassium_mg numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    total_phosphorus_mg numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: health_medication_dose_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_medication_dose_logs (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    medication_id uuid NOT NULL,
    reminder_id uuid,
    scheduled_for timestamp(0) without time zone NOT NULL,
    taken_at timestamp(0) without time zone,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    skip_reason character varying(255),
    notes text,
    notification_sent_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: health_medication_reminders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_medication_reminders (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    medication_id uuid NOT NULL,
    reminder_time time(0) without time zone NOT NULL,
    frequency_type character varying(255) DEFAULT 'daily'::character varying NOT NULL,
    days_of_week json,
    interval_hours smallint,
    timezone character varying(255) DEFAULT 'Asia/Beirut'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notification_enabled boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: health_medications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_medications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    medication_name character varying(255) NOT NULL,
    dosage character varying(255),
    daily_dose character varying(255),
    dose_times json,
    frequency character varying(255),
    start_date date,
    end_date date,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    prescribed_by character varying(255),
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


--
-- Name: health_mood_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_mood_logs (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    mood_date date NOT NULL,
    mood_label character varying(50) NOT NULL,
    mood_score smallint NOT NULL,
    notes text,
    tags jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: health_nutrition_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_nutrition_logs (
    id uuid NOT NULL,
    user_id uuid,
    meal_date date NOT NULL,
    meal_type character varying(50),
    food_name character varying(255) NOT NULL,
    quantity numeric(10,2) DEFAULT '1'::numeric NOT NULL,
    unit character varying(50),
    calories numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    protein numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    sodium numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    potassium numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    phosphorus numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    custom_food_id uuid,
    food_source character varying(50) DEFAULT 'manual'::character varying NOT NULL
);


--
-- Name: health_nutrition_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_nutrition_profiles (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    profile_name character varying(255) DEFAULT 'CKD Daily Nutrition Profile'::character varying NOT NULL,
    daily_calories_min integer,
    daily_calories_max integer,
    daily_protein_max_g numeric(8,2),
    daily_carbs_max_g numeric(8,2),
    daily_fat_max_g numeric(8,2),
    daily_sodium_max_mg numeric(8,2),
    daily_potassium_max_mg numeric(8,2),
    daily_phosphorus_max_mg numeric(8,2),
    is_ckd_safe_mode boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: health_profile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_profile (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    daily_steps_goal integer DEFAULT 8000 NOT NULL,
    stride_length_cm numeric(6,2) DEFAULT '75'::numeric NOT NULL,
    distance_unit character varying(10) DEFAULT 'km'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: health_sleep_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_sleep_logs (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    sleep_date date NOT NULL,
    bed_time timestamp(0) without time zone NOT NULL,
    wake_time timestamp(0) without time zone NOT NULL,
    duration_minutes integer DEFAULT 0 NOT NULL,
    quality_score smallint,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: health_step_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_step_log (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    log_date date NOT NULL,
    steps_count integer DEFAULT 0 NOT NULL,
    distance_km numeric(10,3) DEFAULT '0'::numeric NOT NULL,
    goal_steps integer DEFAULT 8000 NOT NULL,
    goal_percentage numeric(6,2) DEFAULT '0'::numeric NOT NULL,
    goal_completed boolean DEFAULT false NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: health_weight_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_weight_logs (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    log_date date NOT NULL,
    weight_kg numeric(6,2) NOT NULL,
    body_fat_percentage numeric(5,2),
    muscle_mass_kg numeric(6,2),
    bmi numeric(5,2),
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: health_weight_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.health_weight_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: health_weight_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.health_weight_logs_id_seq OWNED BY public.health_weight_logs.id;


--
-- Name: incomes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incomes (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: incomes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.incomes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: incomes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.incomes_id_seq OWNED BY public.incomes.id;


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: life_balance_scores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.life_balance_scores (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    target_date date NOT NULL,
    finance_score smallint DEFAULT '0'::smallint NOT NULL,
    health_score smallint DEFAULT '0'::smallint NOT NULL,
    productivity_score smallint DEFAULT '0'::smallint NOT NULL,
    overall_score smallint DEFAULT '0'::smallint NOT NULL,
    status character varying(255) DEFAULT 'unknown'::character varying NOT NULL,
    finance_breakdown jsonb,
    health_breakdown jsonb,
    productivity_breakdown jsonb,
    recommendations jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: life_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.life_notifications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    notification_type character varying(80) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    severity character varying(30) DEFAULT 'info'::character varying NOT NULL,
    source_module character varying(80),
    metadata jsonb,
    is_read boolean DEFAULT false NOT NULL,
    read_at timestamp(0) without time zone,
    scheduled_for timestamp(0) without time zone,
    triggered_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: model_has_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_has_permissions (
    permission_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id uuid NOT NULL
);


--
-- Name: model_has_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_has_roles (
    role_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id uuid NOT NULL
);


--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_preferences (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    meal_reminders_enabled boolean DEFAULT true NOT NULL,
    breakfast_time time(0) without time zone,
    lunch_time time(0) without time zone,
    dinner_time time(0) without time zone,
    weight_reminders_enabled boolean DEFAULT true NOT NULL,
    weight_reminder_time time(0) without time zone,
    expense_reminders_enabled boolean DEFAULT true NOT NULL,
    expense_reminder_time time(0) without time zone,
    finance_alerts_enabled boolean DEFAULT true NOT NULL,
    health_alerts_enabled boolean DEFAULT true NOT NULL,
    life_balance_alerts_enabled boolean DEFAULT true NOT NULL,
    daily_expense_warning_limit integer,
    life_balance_warning_score integer DEFAULT 60 NOT NULL,
    metadata jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: nutrition_custom_foods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nutrition_custom_foods (
    id uuid NOT NULL,
    user_id uuid,
    name character varying(150) NOT NULL,
    brand character varying(150),
    category character varying(100),
    serving_size numeric(10,2) DEFAULT '100'::numeric NOT NULL,
    serving_unit character varying(50) DEFAULT 'g'::character varying NOT NULL,
    calories numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    protein_g numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    carbs_g numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    fat_g numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    sodium_mg numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    potassium_mg numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    phosphorus_mg numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    is_personal boolean DEFAULT true NOT NULL,
    is_global boolean DEFAULT false NOT NULL,
    is_ai_recommended boolean DEFAULT false NOT NULL,
    ai_metadata json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


--
-- Name: nutrition_food_aliases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nutrition_food_aliases (
    id uuid NOT NULL,
    food_id uuid NOT NULL,
    alias_name character varying(255) NOT NULL,
    language_code character varying(10) DEFAULT 'en'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: nutrition_food_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nutrition_food_categories (
    id uuid NOT NULL,
    name character varying(150) NOT NULL,
    slug character varying(180) NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


--
-- Name: nutrition_food_servings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nutrition_food_servings (
    id uuid NOT NULL,
    food_id uuid NOT NULL,
    serving_label character varying(150) NOT NULL,
    serving_grams numeric(10,2) NOT NULL,
    calories numeric(10,2),
    protein_g numeric(10,2),
    carbs_g numeric(10,2),
    fat_g numeric(10,2),
    sodium_mg numeric(10,2),
    potassium_mg numeric(10,2),
    phosphorus_mg numeric(10,2),
    is_default boolean DEFAULT false NOT NULL,
    display_order integer DEFAULT 1 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT chk_nutrition_food_servings_grams CHECK ((serving_grams > (0)::numeric))
);


--
-- Name: nutrition_food_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nutrition_food_sources (
    id uuid NOT NULL,
    food_id uuid NOT NULL,
    source_name character varying(150) NOT NULL,
    source_food_id character varying(150),
    source_url text,
    imported_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: nutrition_foods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nutrition_foods (
    id uuid NOT NULL,
    category_id uuid,
    food_code character varying(100),
    name character varying(255) NOT NULL,
    brand_name character varying(255),
    description text,
    default_serving_label character varying(100) DEFAULT '100 g'::character varying NOT NULL,
    default_serving_grams numeric(10,2) DEFAULT '100'::numeric NOT NULL,
    calories numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    protein_g numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    carbs_g numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    fat_g numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    fiber_g numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    sugar_g numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    sodium_mg numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    potassium_mg numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    phosphorus_mg numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    calcium_mg numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    iron_mg numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    cholesterol_mg numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    is_ckd_friendly boolean DEFAULT false NOT NULL,
    is_low_sodium boolean DEFAULT false NOT NULL,
    is_low_potassium boolean DEFAULT false NOT NULL,
    is_low_phosphorus boolean DEFAULT false NOT NULL,
    is_low_protein boolean DEFAULT false NOT NULL,
    ckd_warning_level character varying(30) DEFAULT 'medium'::character varying NOT NULL,
    ckd_notes text,
    source character varying(100) DEFAULT 'manual'::character varying NOT NULL,
    source_reference text,
    is_verified boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT chk_nutrition_foods_ckd_warning_level CHECK (((ckd_warning_level)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'avoid'::character varying])::text[]))),
    CONSTRAINT chk_nutrition_foods_default_serving_grams CHECK ((default_serving_grams > (0)::numeric)),
    CONSTRAINT chk_nutrition_foods_values_non_negative CHECK (((calories >= (0)::numeric) AND (protein_g >= (0)::numeric) AND (carbs_g >= (0)::numeric) AND (fat_g >= (0)::numeric) AND (sodium_mg >= (0)::numeric) AND (potassium_mg >= (0)::numeric) AND (phosphorus_mg >= (0)::numeric)))
);


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plans (
    id uuid NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    monthly_price numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    yearly_price numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    max_finance_accounts integer DEFAULT 3 NOT NULL,
    max_projects integer DEFAULT 3 NOT NULL,
    max_ai_insights_per_month integer DEFAULT 30 NOT NULL,
    max_notifications_per_month integer DEFAULT 100 NOT NULL,
    finance_module_enabled boolean DEFAULT true NOT NULL,
    health_module_enabled boolean DEFAULT true NOT NULL,
    projects_module_enabled boolean DEFAULT true NOT NULL,
    ai_module_enabled boolean DEFAULT false NOT NULL,
    automation_module_enabled boolean DEFAULT false NOT NULL,
    monitoring_module_enabled boolean DEFAULT false NOT NULL,
    features jsonb,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: productivity_calendar_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.productivity_calendar_events (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    event_type character varying(255) DEFAULT 'task'::character varying NOT NULL,
    status character varying(255) DEFAULT 'scheduled'::character varying NOT NULL,
    start_time timestamp(0) without time zone NOT NULL,
    end_time timestamp(0) without time zone,
    location character varying(255),
    metadata jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: productivity_goals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.productivity_goals (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    category character varying(255),
    priority character varying(255) DEFAULT 'medium'::character varying NOT NULL,
    progress_percentage numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    target_date date,
    completed_at timestamp(0) without time zone,
    metadata jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: productivity_habit_check_ins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.productivity_habit_check_ins (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    habit_id uuid NOT NULL,
    check_in_date date NOT NULL,
    status character varying(255) DEFAULT 'completed'::character varying NOT NULL,
    count integer DEFAULT 1 NOT NULL,
    notes text,
    metadata jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: productivity_habits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.productivity_habits (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    frequency character varying(255) DEFAULT 'daily'::character varying NOT NULL,
    target_count integer DEFAULT 1 NOT NULL,
    completed_count_today integer DEFAULT 0 NOT NULL,
    current_streak integer DEFAULT 0 NOT NULL,
    best_streak integer DEFAULT 0 NOT NULL,
    last_completed_at timestamp(0) without time zone,
    metadata jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: productivity_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.productivity_tasks (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    status character varying(255) DEFAULT 'todo'::character varying NOT NULL,
    priority character varying(255) DEFAULT 'medium'::character varying NOT NULL,
    progress_percentage numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    start_date date,
    due_date date,
    completed_at timestamp(0) without time zone,
    metadata jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: project_milestones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_milestones (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    milestone_name character varying(255) NOT NULL,
    description text,
    target_date date,
    completed_date date,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    progress_percentage smallint DEFAULT '0'::smallint NOT NULL,
    weight numeric(8,2) DEFAULT '1'::numeric NOT NULL,
    metadata jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT project_milestones_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'in_progress'::character varying, 'completed'::character varying, 'blocked'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- Name: project_status_updates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_status_updates (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    task_id uuid,
    milestone_id uuid,
    update_title character varying(255) NOT NULL,
    update_description text,
    old_status character varying(255),
    new_status character varying(255),
    old_progress_percentage smallint,
    new_progress_percentage smallint,
    update_type character varying(255) DEFAULT 'manual'::character varying NOT NULL,
    metadata jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT project_status_updates_update_type_check CHECK (((update_type)::text = ANY ((ARRAY['manual'::character varying, 'task_progress'::character varying, 'milestone_progress'::character varying, 'auto_calculation'::character varying, 'status_change'::character varying])::text[])))
);


--
-- Name: project_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_tasks (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    user_id uuid NOT NULL,
    task_title character varying(255) NOT NULL,
    task_description text,
    status character varying(255) DEFAULT 'todo'::character varying NOT NULL,
    priority character varying(255) DEFAULT 'medium'::character varying NOT NULL,
    task_order integer DEFAULT 1 NOT NULL,
    start_date date,
    due_date date,
    completed_date date,
    progress_percentage numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    metadata jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    weight numeric(8,2) DEFAULT '1'::numeric NOT NULL,
    completed_at timestamp(0) without time zone
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    project_name character varying(255) NOT NULL,
    project_code character varying(255),
    description text,
    status character varying(255) DEFAULT 'not_started'::character varying NOT NULL,
    priority character varying(255) DEFAULT 'medium'::character varying NOT NULL,
    start_date date,
    target_end_date date,
    actual_end_date date,
    progress_percentage numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    metadata jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: role_has_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_has_permissions (
    permission_id bigint NOT NULL,
    role_id bigint NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: step_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.step_entries (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: step_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.step_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: step_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.step_entries_id_seq OWNED BY public.step_entries.id;


--
-- Name: subscription_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_usage (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    subscription_id uuid NOT NULL,
    finance_accounts_count integer DEFAULT 0 NOT NULL,
    projects_count integer DEFAULT 0 NOT NULL,
    ai_insights_used integer DEFAULT 0 NOT NULL,
    notifications_sent integer DEFAULT 0 NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscriptions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    plan_id uuid NOT NULL,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    billing_cycle character varying(255) DEFAULT 'monthly'::character varying NOT NULL,
    started_at timestamp(0) without time zone,
    trial_ends_at timestamp(0) without time zone,
    current_period_starts_at timestamp(0) without time zone,
    current_period_ends_at timestamp(0) without time zone,
    cancelled_at timestamp(0) without time zone,
    payment_provider character varying(255),
    payment_customer_id character varying(255),
    payment_subscription_id character varying(255),
    metadata jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: system_monitoring_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_monitoring_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_name character varying(255) NOT NULL,
    status character varying(255) DEFAULT 'healthy'::character varying NOT NULL,
    response_time_ms integer,
    metrics jsonb,
    message text,
    checked_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    user_id uuid,
    title character varying(255),
    description text,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    priority character varying(255) DEFAULT 'medium'::character varying NOT NULL,
    due_date date,
    completed_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    name character varying(150) NOT NULL,
    email character varying(190) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    role character varying(50) DEFAULT 'user'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_login_at timestamp(0) without time zone,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: weight_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.weight_entries (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: weight_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.weight_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: weight_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.weight_entries_id_seq OWNED BY public.weight_entries.id;


--
-- Name: calorie_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calorie_entries ALTER COLUMN id SET DEFAULT nextval('public.calorie_entries_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: finance_core_tables id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_core_tables ALTER COLUMN id SET DEFAULT nextval('public.finance_core_tables_id_seq'::regclass);


--
-- Name: health_lab_tests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_lab_tests ALTER COLUMN id SET DEFAULT nextval('public.health_lab_tests_id_seq'::regclass);


--
-- Name: health_weight_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_weight_logs ALTER COLUMN id SET DEFAULT nextval('public.health_weight_logs_id_seq'::regclass);


--
-- Name: incomes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incomes ALTER COLUMN id SET DEFAULT nextval('public.incomes_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: step_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.step_entries ALTER COLUMN id SET DEFAULT nextval('public.step_entries_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: weight_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weight_entries ALTER COLUMN id SET DEFAULT nextval('public.weight_entries_id_seq'::regclass);


--
-- Name: app_user app_user_email_key; Type: CONSTRAINT; Schema: nix_life_os; Owner: -
--

ALTER TABLE ONLY nix_life_os.app_user
    ADD CONSTRAINT app_user_email_key UNIQUE (email);


--
-- Name: app_user app_user_pkey; Type: CONSTRAINT; Schema: nix_life_os; Owner: -
--

ALTER TABLE ONLY nix_life_os.app_user
    ADD CONSTRAINT app_user_pkey PRIMARY KEY (user_id);


--
-- Name: app_user app_user_username_key; Type: CONSTRAINT; Schema: nix_life_os; Owner: -
--

ALTER TABLE ONLY nix_life_os.app_user
    ADD CONSTRAINT app_user_username_key UNIQUE (username);


--
-- Name: finance_account finance_account_pkey; Type: CONSTRAINT; Schema: nix_life_os; Owner: -
--

ALTER TABLE ONLY nix_life_os.finance_account
    ADD CONSTRAINT finance_account_pkey PRIMARY KEY (id);


--
-- Name: finance_budget finance_budget_pkey; Type: CONSTRAINT; Schema: nix_life_os; Owner: -
--

ALTER TABLE ONLY nix_life_os.finance_budget
    ADD CONSTRAINT finance_budget_pkey PRIMARY KEY (id);


--
-- Name: finance_category finance_category_pkey; Type: CONSTRAINT; Schema: nix_life_os; Owner: -
--

ALTER TABLE ONLY nix_life_os.finance_category
    ADD CONSTRAINT finance_category_pkey PRIMARY KEY (id);


--
-- Name: finance_transaction finance_transaction_pkey; Type: CONSTRAINT; Schema: nix_life_os; Owner: -
--

ALTER TABLE ONLY nix_life_os.finance_transaction
    ADD CONSTRAINT finance_transaction_pkey PRIMARY KEY (id);


--
-- Name: health_meal_log health_meal_log_pkey; Type: CONSTRAINT; Schema: nix_life_os; Owner: -
--

ALTER TABLE ONLY nix_life_os.health_meal_log
    ADD CONSTRAINT health_meal_log_pkey PRIMARY KEY (meal_log_id);


--
-- Name: health_step_log health_step_log_pkey; Type: CONSTRAINT; Schema: nix_life_os; Owner: -
--

ALTER TABLE ONLY nix_life_os.health_step_log
    ADD CONSTRAINT health_step_log_pkey PRIMARY KEY (step_log_id);


--
-- Name: health_step_log health_step_log_user_id_log_date_source_key; Type: CONSTRAINT; Schema: nix_life_os; Owner: -
--

ALTER TABLE ONLY nix_life_os.health_step_log
    ADD CONSTRAINT health_step_log_user_id_log_date_source_key UNIQUE (user_id, log_date, source);


--
-- Name: ai_alerts ai_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_alerts
    ADD CONSTRAINT ai_alerts_pkey PRIMARY KEY (id);


--
-- Name: ai_insights ai_insights_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_insights
    ADD CONSTRAINT ai_insights_pkey PRIMARY KEY (id);


--
-- Name: ai_predictions ai_predictions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_predictions
    ADD CONSTRAINT ai_predictions_pkey PRIMARY KEY (id);


--
-- Name: ai_recommendation_feedback ai_recommendation_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_recommendation_feedback
    ADD CONSTRAINT ai_recommendation_feedback_pkey PRIMARY KEY (id);


--
-- Name: ai_recommendation_rules ai_recommendation_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_recommendation_rules
    ADD CONSTRAINT ai_recommendation_rules_pkey PRIMARY KEY (id);


--
-- Name: ai_recommendation_rules ai_recommendation_rules_rule_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_recommendation_rules
    ADD CONSTRAINT ai_recommendation_rules_rule_code_unique UNIQUE (rule_code);


--
-- Name: ai_recommendations ai_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_recommendations
    ADD CONSTRAINT ai_recommendations_pkey PRIMARY KEY (id);


--
-- Name: ai_reports ai_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_reports
    ADD CONSTRAINT ai_reports_pkey PRIMARY KEY (id);


--
-- Name: ai_user_daily_scores ai_user_daily_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_user_daily_scores
    ADD CONSTRAINT ai_user_daily_scores_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: automation_rules automation_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_rules
    ADD CONSTRAINT automation_rules_pkey PRIMARY KEY (id);


--
-- Name: automation_trigger_logs automation_trigger_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_trigger_logs
    ADD CONSTRAINT automation_trigger_logs_pkey PRIMARY KEY (id);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: calorie_entries calorie_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calorie_entries
    ADD CONSTRAINT calorie_entries_pkey PRIMARY KEY (id);


--
-- Name: error_logs error_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_logs
    ADD CONSTRAINT error_logs_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: finance_accounts finance_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_accounts
    ADD CONSTRAINT finance_accounts_pkey PRIMARY KEY (id);


--
-- Name: finance_budget_lines finance_budget_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_budget_lines
    ADD CONSTRAINT finance_budget_lines_pkey PRIMARY KEY (id);


--
-- Name: finance_budgets finance_budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_budgets
    ADD CONSTRAINT finance_budgets_pkey PRIMARY KEY (id);


--
-- Name: finance_core_tables finance_core_tables_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_core_tables
    ADD CONSTRAINT finance_core_tables_pkey PRIMARY KEY (id);


--
-- Name: finance_transactions finance_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_transactions
    ADD CONSTRAINT finance_transactions_pkey PRIMARY KEY (id);


--
-- Name: health_alert_rules health_alert_rules_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_alert_rules
    ADD CONSTRAINT health_alert_rules_code_unique UNIQUE (code);


--
-- Name: health_alert_rules health_alert_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_alert_rules
    ADD CONSTRAINT health_alert_rules_pkey PRIMARY KEY (id);


--
-- Name: health_alerts health_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_alerts
    ADD CONSTRAINT health_alerts_pkey PRIMARY KEY (id);


--
-- Name: health_food_items health_food_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_food_items
    ADD CONSTRAINT health_food_items_pkey PRIMARY KEY (id);


--
-- Name: health_hydration_logs health_hydration_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_hydration_logs
    ADD CONSTRAINT health_hydration_logs_pkey PRIMARY KEY (id);


--
-- Name: health_lab_tests health_lab_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_lab_tests
    ADD CONSTRAINT health_lab_tests_pkey PRIMARY KEY (id);


--
-- Name: health_meal_log_items health_meal_log_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_meal_log_items
    ADD CONSTRAINT health_meal_log_items_pkey PRIMARY KEY (id);


--
-- Name: health_meal_logs health_meal_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_meal_logs
    ADD CONSTRAINT health_meal_logs_pkey PRIMARY KEY (id);


--
-- Name: health_medication_dose_logs health_medication_dose_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_medication_dose_logs
    ADD CONSTRAINT health_medication_dose_logs_pkey PRIMARY KEY (id);


--
-- Name: health_medication_reminders health_medication_reminders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_medication_reminders
    ADD CONSTRAINT health_medication_reminders_pkey PRIMARY KEY (id);


--
-- Name: health_medications health_medications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_medications
    ADD CONSTRAINT health_medications_pkey PRIMARY KEY (id);


--
-- Name: health_mood_logs health_mood_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_mood_logs
    ADD CONSTRAINT health_mood_logs_pkey PRIMARY KEY (id);


--
-- Name: health_nutrition_logs health_nutrition_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_nutrition_logs
    ADD CONSTRAINT health_nutrition_logs_pkey PRIMARY KEY (id);


--
-- Name: health_nutrition_profiles health_nutrition_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_nutrition_profiles
    ADD CONSTRAINT health_nutrition_profiles_pkey PRIMARY KEY (id);


--
-- Name: health_nutrition_profiles health_nutrition_profiles_user_id_is_active_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_nutrition_profiles
    ADD CONSTRAINT health_nutrition_profiles_user_id_is_active_unique UNIQUE (user_id, is_active);


--
-- Name: health_profile health_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_profile
    ADD CONSTRAINT health_profile_pkey PRIMARY KEY (id);


--
-- Name: health_profile health_profile_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_profile
    ADD CONSTRAINT health_profile_user_id_unique UNIQUE (user_id);


--
-- Name: health_sleep_logs health_sleep_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_sleep_logs
    ADD CONSTRAINT health_sleep_logs_pkey PRIMARY KEY (id);


--
-- Name: health_step_log health_step_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_step_log
    ADD CONSTRAINT health_step_log_pkey PRIMARY KEY (id);


--
-- Name: health_step_log health_step_log_user_id_log_date_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_step_log
    ADD CONSTRAINT health_step_log_user_id_log_date_unique UNIQUE (user_id, log_date);


--
-- Name: health_weight_logs health_weight_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_weight_logs
    ADD CONSTRAINT health_weight_logs_pkey PRIMARY KEY (id);


--
-- Name: health_weight_logs health_weight_logs_user_id_log_date_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_weight_logs
    ADD CONSTRAINT health_weight_logs_user_id_log_date_unique UNIQUE (user_id, log_date);


--
-- Name: incomes incomes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incomes
    ADD CONSTRAINT incomes_pkey PRIMARY KEY (id);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: life_balance_scores life_balance_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.life_balance_scores
    ADD CONSTRAINT life_balance_scores_pkey PRIMARY KEY (id);


--
-- Name: life_balance_scores life_balance_scores_user_id_target_date_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.life_balance_scores
    ADD CONSTRAINT life_balance_scores_user_id_target_date_unique UNIQUE (user_id, target_date);


--
-- Name: life_notifications life_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.life_notifications
    ADD CONSTRAINT life_notifications_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: model_has_permissions model_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_pkey PRIMARY KEY (permission_id, model_id, model_type);


--
-- Name: model_has_roles model_has_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_pkey PRIMARY KEY (role_id, model_id, model_type);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_unique UNIQUE (user_id);


--
-- Name: nutrition_custom_foods nutrition_custom_foods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_custom_foods
    ADD CONSTRAINT nutrition_custom_foods_pkey PRIMARY KEY (id);


--
-- Name: nutrition_custom_foods nutrition_custom_foods_user_id_name_brand_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_custom_foods
    ADD CONSTRAINT nutrition_custom_foods_user_id_name_brand_unique UNIQUE (user_id, name, brand);


--
-- Name: nutrition_food_aliases nutrition_food_aliases_food_id_alias_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_food_aliases
    ADD CONSTRAINT nutrition_food_aliases_food_id_alias_name_unique UNIQUE (food_id, alias_name);


--
-- Name: nutrition_food_aliases nutrition_food_aliases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_food_aliases
    ADD CONSTRAINT nutrition_food_aliases_pkey PRIMARY KEY (id);


--
-- Name: nutrition_food_categories nutrition_food_categories_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_food_categories
    ADD CONSTRAINT nutrition_food_categories_name_unique UNIQUE (name);


--
-- Name: nutrition_food_categories nutrition_food_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_food_categories
    ADD CONSTRAINT nutrition_food_categories_pkey PRIMARY KEY (id);


--
-- Name: nutrition_food_categories nutrition_food_categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_food_categories
    ADD CONSTRAINT nutrition_food_categories_slug_unique UNIQUE (slug);


--
-- Name: nutrition_food_servings nutrition_food_servings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_food_servings
    ADD CONSTRAINT nutrition_food_servings_pkey PRIMARY KEY (id);


--
-- Name: nutrition_food_sources nutrition_food_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_food_sources
    ADD CONSTRAINT nutrition_food_sources_pkey PRIMARY KEY (id);


--
-- Name: nutrition_foods nutrition_foods_food_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_foods
    ADD CONSTRAINT nutrition_foods_food_code_unique UNIQUE (food_code);


--
-- Name: nutrition_foods nutrition_foods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_foods
    ADD CONSTRAINT nutrition_foods_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_guard_name_unique UNIQUE (name, guard_name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: plans plans_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_code_unique UNIQUE (code);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: productivity_calendar_events productivity_calendar_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.productivity_calendar_events
    ADD CONSTRAINT productivity_calendar_events_pkey PRIMARY KEY (id);


--
-- Name: productivity_goals productivity_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.productivity_goals
    ADD CONSTRAINT productivity_goals_pkey PRIMARY KEY (id);


--
-- Name: productivity_habit_check_ins productivity_habit_check_ins_habit_id_check_in_date_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.productivity_habit_check_ins
    ADD CONSTRAINT productivity_habit_check_ins_habit_id_check_in_date_unique UNIQUE (habit_id, check_in_date);


--
-- Name: productivity_habit_check_ins productivity_habit_check_ins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.productivity_habit_check_ins
    ADD CONSTRAINT productivity_habit_check_ins_pkey PRIMARY KEY (id);


--
-- Name: productivity_habits productivity_habits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.productivity_habits
    ADD CONSTRAINT productivity_habits_pkey PRIMARY KEY (id);


--
-- Name: productivity_tasks productivity_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.productivity_tasks
    ADD CONSTRAINT productivity_tasks_pkey PRIMARY KEY (id);


--
-- Name: project_milestones project_milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_milestones
    ADD CONSTRAINT project_milestones_pkey PRIMARY KEY (id);


--
-- Name: project_status_updates project_status_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_status_updates
    ADD CONSTRAINT project_status_updates_pkey PRIMARY KEY (id);


--
-- Name: project_tasks project_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT project_tasks_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: role_has_permissions role_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_pkey PRIMARY KEY (permission_id, role_id);


--
-- Name: roles roles_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_guard_name_unique UNIQUE (name, guard_name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: step_entries step_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.step_entries
    ADD CONSTRAINT step_entries_pkey PRIMARY KEY (id);


--
-- Name: subscription_usage subscription_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_usage
    ADD CONSTRAINT subscription_usage_pkey PRIMARY KEY (id);


--
-- Name: subscription_usage subscription_usage_user_id_subscription_id_period_start_period_; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_usage
    ADD CONSTRAINT subscription_usage_user_id_subscription_id_period_start_period_ UNIQUE (user_id, subscription_id, period_start, period_end);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_user_id_status_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_status_unique UNIQUE (user_id, status);


--
-- Name: system_monitoring_logs system_monitoring_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_monitoring_logs
    ADD CONSTRAINT system_monitoring_logs_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: health_medication_dose_logs unique_medication_dose_schedule; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_medication_dose_logs
    ADD CONSTRAINT unique_medication_dose_schedule UNIQUE (user_id, medication_id, reminder_id, scheduled_for);


--
-- Name: ai_recommendations uq_ai_recommendations_user_duplicate_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_recommendations
    ADD CONSTRAINT uq_ai_recommendations_user_duplicate_key UNIQUE (user_id, duplicate_key);


--
-- Name: ai_user_daily_scores uq_ai_user_daily_scores_user_date; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_user_daily_scores
    ADD CONSTRAINT uq_ai_user_daily_scores_user_date UNIQUE (user_id, score_date);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: weight_entries weight_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weight_entries
    ADD CONSTRAINT weight_entries_pkey PRIMARY KEY (id);


--
-- Name: idx_app_user_status; Type: INDEX; Schema: nix_life_os; Owner: -
--

CREATE INDEX idx_app_user_status ON nix_life_os.app_user USING btree (status);


--
-- Name: idx_finance_account_user_id; Type: INDEX; Schema: nix_life_os; Owner: -
--

CREATE INDEX idx_finance_account_user_id ON nix_life_os.finance_account USING btree (user_id);


--
-- Name: idx_finance_budget_category_id; Type: INDEX; Schema: nix_life_os; Owner: -
--

CREATE INDEX idx_finance_budget_category_id ON nix_life_os.finance_budget USING btree (category_id);


--
-- Name: idx_finance_budget_user_id; Type: INDEX; Schema: nix_life_os; Owner: -
--

CREATE INDEX idx_finance_budget_user_id ON nix_life_os.finance_budget USING btree (user_id);


--
-- Name: idx_finance_category_user_id; Type: INDEX; Schema: nix_life_os; Owner: -
--

CREATE INDEX idx_finance_category_user_id ON nix_life_os.finance_category USING btree (user_id);


--
-- Name: idx_finance_transaction_account_id; Type: INDEX; Schema: nix_life_os; Owner: -
--

CREATE INDEX idx_finance_transaction_account_id ON nix_life_os.finance_transaction USING btree (account_id);


--
-- Name: idx_finance_transaction_category_id; Type: INDEX; Schema: nix_life_os; Owner: -
--

CREATE INDEX idx_finance_transaction_category_id ON nix_life_os.finance_transaction USING btree (category_id);


--
-- Name: idx_finance_transaction_user_id; Type: INDEX; Schema: nix_life_os; Owner: -
--

CREATE INDEX idx_finance_transaction_user_id ON nix_life_os.finance_transaction USING btree (user_id);


--
-- Name: idx_health_step_logs_user_date; Type: INDEX; Schema: nix_life_os; Owner: -
--

CREATE INDEX idx_health_step_logs_user_date ON nix_life_os.health_step_log USING btree (user_id, log_date);


--
-- Name: idx_meal_log_totals_gin; Type: INDEX; Schema: nix_life_os; Owner: -
--

CREATE INDEX idx_meal_log_totals_gin ON nix_life_os.health_meal_log USING gin (totals_json);


--
-- Name: idx_meal_log_user_consumed; Type: INDEX; Schema: nix_life_os; Owner: -
--

CREATE INDEX idx_meal_log_user_consumed ON nix_life_os.health_meal_log USING btree (user_id, consumed_at DESC);


--
-- Name: idx_step_log_payload_gin; Type: INDEX; Schema: nix_life_os; Owner: -
--

CREATE INDEX idx_step_log_payload_gin ON nix_life_os.health_step_log USING gin (source_payload_json);


--
-- Name: idx_step_log_user_date; Type: INDEX; Schema: nix_life_os; Owner: -
--

CREATE INDEX idx_step_log_user_date ON nix_life_os.health_step_log USING btree (user_id, log_date DESC);


--
-- Name: ai_alerts_alert_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_alerts_alert_date_index ON public.ai_alerts USING btree (alert_date);


--
-- Name: ai_alerts_alert_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_alerts_alert_type_index ON public.ai_alerts USING btree (alert_type);


--
-- Name: ai_alerts_module_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_alerts_module_index ON public.ai_alerts USING btree (module);


--
-- Name: ai_alerts_severity_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_alerts_severity_index ON public.ai_alerts USING btree (severity);


--
-- Name: ai_alerts_user_id_alert_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_alerts_user_id_alert_date_index ON public.ai_alerts USING btree (user_id, alert_date);


--
-- Name: ai_alerts_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_alerts_user_id_index ON public.ai_alerts USING btree (user_id);


--
-- Name: ai_alerts_user_id_is_resolved_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_alerts_user_id_is_resolved_index ON public.ai_alerts USING btree (user_id, is_resolved);


--
-- Name: ai_insights_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_insights_category_index ON public.ai_insights USING btree (category);


--
-- Name: ai_insights_insight_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_insights_insight_date_index ON public.ai_insights USING btree (insight_date);


--
-- Name: ai_insights_insight_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_insights_insight_type_index ON public.ai_insights USING btree (insight_type);


--
-- Name: ai_insights_severity_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_insights_severity_index ON public.ai_insights USING btree (severity);


--
-- Name: ai_insights_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_insights_user_id_index ON public.ai_insights USING btree (user_id);


--
-- Name: ai_insights_user_id_insight_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_insights_user_id_insight_date_index ON public.ai_insights USING btree (user_id, insight_date);


--
-- Name: ai_insights_user_id_severity_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_insights_user_id_severity_index ON public.ai_insights USING btree (user_id, severity);


--
-- Name: ai_predictions_prediction_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_predictions_prediction_date_index ON public.ai_predictions USING btree (prediction_date);


--
-- Name: ai_predictions_target_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_predictions_target_date_index ON public.ai_predictions USING btree (target_date);


--
-- Name: ai_predictions_user_id_prediction_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_predictions_user_id_prediction_type_index ON public.ai_predictions USING btree (user_id, prediction_type);


--
-- Name: ai_reports_period_end_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_reports_period_end_index ON public.ai_reports USING btree (period_end);


--
-- Name: ai_reports_period_start_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_reports_period_start_index ON public.ai_reports USING btree (period_start);


--
-- Name: ai_reports_report_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_reports_report_type_index ON public.ai_reports USING btree (report_type);


--
-- Name: ai_reports_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_reports_user_id_index ON public.ai_reports USING btree (user_id);


--
-- Name: ai_reports_user_id_period_start_period_end_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_reports_user_id_period_start_period_end_index ON public.ai_reports USING btree (user_id, period_start, period_end);


--
-- Name: ai_reports_user_id_report_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_reports_user_id_report_type_index ON public.ai_reports USING btree (user_id, report_type);


--
-- Name: audit_logs_action_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_action_index ON public.audit_logs USING btree (action);


--
-- Name: audit_logs_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_created_at_index ON public.audit_logs USING btree (created_at);


--
-- Name: audit_logs_entity_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_entity_type_index ON public.audit_logs USING btree (entity_type);


--
-- Name: audit_logs_module_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_module_index ON public.audit_logs USING btree (module);


--
-- Name: audit_logs_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_user_id_index ON public.audit_logs USING btree (user_id);


--
-- Name: automation_rules_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX automation_rules_user_id_is_active_index ON public.automation_rules USING btree (user_id, is_active);


--
-- Name: automation_rules_user_id_module_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX automation_rules_user_id_module_index ON public.automation_rules USING btree (user_id, module);


--
-- Name: automation_rules_user_id_trigger_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX automation_rules_user_id_trigger_type_index ON public.automation_rules USING btree (user_id, trigger_type);


--
-- Name: automation_trigger_logs_automation_rule_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX automation_trigger_logs_automation_rule_id_index ON public.automation_trigger_logs USING btree (automation_rule_id);


--
-- Name: automation_trigger_logs_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX automation_trigger_logs_status_index ON public.automation_trigger_logs USING btree (status);


--
-- Name: automation_trigger_logs_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX automation_trigger_logs_user_id_index ON public.automation_trigger_logs USING btree (user_id);


--
-- Name: cache_expiration_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cache_expiration_index ON public.cache USING btree (expiration);


--
-- Name: cache_locks_expiration_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cache_locks_expiration_index ON public.cache_locks USING btree (expiration);


--
-- Name: error_logs_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_logs_created_at_index ON public.error_logs USING btree (created_at);


--
-- Name: error_logs_exception_class_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_logs_exception_class_index ON public.error_logs USING btree (exception_class);


--
-- Name: error_logs_level_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_logs_level_index ON public.error_logs USING btree (level);


--
-- Name: error_logs_module_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_logs_module_index ON public.error_logs USING btree (module);


--
-- Name: error_logs_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_logs_user_id_index ON public.error_logs USING btree (user_id);


--
-- Name: finance_accounts_user_id_account_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_accounts_user_id_account_type_index ON public.finance_accounts USING btree (user_id, account_type);


--
-- Name: finance_accounts_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_accounts_user_id_index ON public.finance_accounts USING btree (user_id);


--
-- Name: finance_accounts_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_accounts_user_id_is_active_index ON public.finance_accounts USING btree (user_id, is_active);


--
-- Name: finance_budget_lines_account_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_budget_lines_account_id_index ON public.finance_budget_lines USING btree (account_id);


--
-- Name: finance_budget_lines_budget_id_account_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_budget_lines_budget_id_account_id_index ON public.finance_budget_lines USING btree (budget_id, account_id);


--
-- Name: finance_budget_lines_budget_id_category_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_budget_lines_budget_id_category_id_index ON public.finance_budget_lines USING btree (budget_id, category_id);


--
-- Name: finance_budget_lines_budget_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_budget_lines_budget_id_index ON public.finance_budget_lines USING btree (budget_id);


--
-- Name: finance_budget_lines_category_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_budget_lines_category_id_index ON public.finance_budget_lines USING btree (category_id);


--
-- Name: finance_budget_lines_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_budget_lines_user_id_index ON public.finance_budget_lines USING btree (user_id);


--
-- Name: finance_budgets_user_id_budget_month_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_budgets_user_id_budget_month_index ON public.finance_budgets USING btree (user_id, budget_month);


--
-- Name: finance_budgets_user_id_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_budgets_user_id_category_index ON public.finance_budgets USING btree (user_id, category);


--
-- Name: finance_budgets_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_budgets_user_id_index ON public.finance_budgets USING btree (user_id);


--
-- Name: finance_budgets_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_budgets_user_id_is_active_index ON public.finance_budgets USING btree (user_id, is_active);


--
-- Name: finance_transactions_account_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_transactions_account_id_index ON public.finance_transactions USING btree (account_id);


--
-- Name: finance_transactions_account_id_transaction_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_transactions_account_id_transaction_date_index ON public.finance_transactions USING btree (account_id, transaction_date);


--
-- Name: finance_transactions_category_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_transactions_category_id_index ON public.finance_transactions USING btree (category_id);


--
-- Name: finance_transactions_transfer_account_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_transactions_transfer_account_id_index ON public.finance_transactions USING btree (transfer_account_id);


--
-- Name: finance_transactions_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_transactions_user_id_index ON public.finance_transactions USING btree (user_id);


--
-- Name: finance_transactions_user_id_transaction_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_transactions_user_id_transaction_date_index ON public.finance_transactions USING btree (user_id, transaction_date);


--
-- Name: finance_transactions_user_id_transaction_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_transactions_user_id_transaction_type_index ON public.finance_transactions USING btree (user_id, transaction_type);


--
-- Name: health_alert_rules_category_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_alert_rules_category_is_active_index ON public.health_alert_rules USING btree (category, is_active);


--
-- Name: health_alerts_alert_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_alerts_alert_type_index ON public.health_alerts USING btree (alert_type);


--
-- Name: health_alerts_user_id_alert_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_alerts_user_id_alert_date_index ON public.health_alerts USING btree (user_id, alert_date);


--
-- Name: health_alerts_user_id_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_alerts_user_id_category_index ON public.health_alerts USING btree (user_id, category);


--
-- Name: health_alerts_user_id_severity_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_alerts_user_id_severity_index ON public.health_alerts USING btree (user_id, severity);


--
-- Name: health_alerts_user_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_alerts_user_id_status_index ON public.health_alerts USING btree (user_id, status);


--
-- Name: health_food_items_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_food_items_category_index ON public.health_food_items USING btree (category);


--
-- Name: health_food_items_food_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_food_items_food_name_index ON public.health_food_items USING btree (food_name);


--
-- Name: health_food_items_is_ckd_friendly_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_food_items_is_ckd_friendly_index ON public.health_food_items USING btree (is_ckd_friendly);


--
-- Name: health_food_items_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_food_items_user_id_index ON public.health_food_items USING btree (user_id);


--
-- Name: health_hydration_logs_user_id_drink_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_hydration_logs_user_id_drink_type_index ON public.health_hydration_logs USING btree (user_id, drink_type);


--
-- Name: health_hydration_logs_user_id_log_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_hydration_logs_user_id_log_date_index ON public.health_hydration_logs USING btree (user_id, log_date);


--
-- Name: health_lab_tests_test_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_lab_tests_test_date_index ON public.health_lab_tests USING btree (test_date);


--
-- Name: health_lab_tests_test_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_lab_tests_test_name_index ON public.health_lab_tests USING btree (test_name);


--
-- Name: health_lab_tests_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_lab_tests_user_id_index ON public.health_lab_tests USING btree (user_id);


--
-- Name: health_meal_log_items_food_item_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_meal_log_items_food_item_id_index ON public.health_meal_log_items USING btree (food_item_id);


--
-- Name: health_meal_log_items_meal_log_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_meal_log_items_meal_log_id_index ON public.health_meal_log_items USING btree (meal_log_id);


--
-- Name: health_meal_logs_meal_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_meal_logs_meal_type_index ON public.health_meal_logs USING btree (meal_type);


--
-- Name: health_meal_logs_user_id_meal_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_meal_logs_user_id_meal_date_index ON public.health_meal_logs USING btree (user_id, meal_date);


--
-- Name: health_medication_dose_logs_medication_id_scheduled_for_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_medication_dose_logs_medication_id_scheduled_for_index ON public.health_medication_dose_logs USING btree (medication_id, scheduled_for);


--
-- Name: health_medication_dose_logs_user_id_scheduled_for_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_medication_dose_logs_user_id_scheduled_for_index ON public.health_medication_dose_logs USING btree (user_id, scheduled_for);


--
-- Name: health_medication_dose_logs_user_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_medication_dose_logs_user_id_status_index ON public.health_medication_dose_logs USING btree (user_id, status);


--
-- Name: health_medication_reminders_medication_id_reminder_time_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_medication_reminders_medication_id_reminder_time_index ON public.health_medication_reminders USING btree (medication_id, reminder_time);


--
-- Name: health_medication_reminders_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_medication_reminders_user_id_is_active_index ON public.health_medication_reminders USING btree (user_id, is_active);


--
-- Name: health_medications_user_id_medication_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_medications_user_id_medication_name_index ON public.health_medications USING btree (user_id, medication_name);


--
-- Name: health_medications_user_id_start_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_medications_user_id_start_date_index ON public.health_medications USING btree (user_id, start_date);


--
-- Name: health_medications_user_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_medications_user_id_status_index ON public.health_medications USING btree (user_id, status);


--
-- Name: health_mood_logs_mood_score_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_mood_logs_mood_score_index ON public.health_mood_logs USING btree (mood_score);


--
-- Name: health_mood_logs_user_id_mood_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_mood_logs_user_id_mood_date_index ON public.health_mood_logs USING btree (user_id, mood_date);


--
-- Name: health_nutrition_logs_meal_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_nutrition_logs_meal_date_index ON public.health_nutrition_logs USING btree (meal_date);


--
-- Name: health_nutrition_logs_meal_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_nutrition_logs_meal_type_index ON public.health_nutrition_logs USING btree (meal_type);


--
-- Name: health_nutrition_logs_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_nutrition_logs_user_id_index ON public.health_nutrition_logs USING btree (user_id);


--
-- Name: health_nutrition_profiles_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_nutrition_profiles_user_id_index ON public.health_nutrition_profiles USING btree (user_id);


--
-- Name: health_sleep_logs_user_id_sleep_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_sleep_logs_user_id_sleep_date_index ON public.health_sleep_logs USING btree (user_id, sleep_date);


--
-- Name: health_step_log_user_id_log_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_step_log_user_id_log_date_index ON public.health_step_log USING btree (user_id, log_date);


--
-- Name: health_weight_logs_user_id_log_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_weight_logs_user_id_log_date_index ON public.health_weight_logs USING btree (user_id, log_date);


--
-- Name: health_weight_logs_user_id_weight_kg_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_weight_logs_user_id_weight_kg_index ON public.health_weight_logs USING btree (user_id, weight_kg);


--
-- Name: idx_ai_daily_scores_classification; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_daily_scores_classification ON public.ai_user_daily_scores USING btree (classification);


--
-- Name: idx_ai_daily_scores_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_daily_scores_date ON public.ai_user_daily_scores USING btree (score_date);


--
-- Name: idx_ai_daily_scores_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_daily_scores_user ON public.ai_user_daily_scores USING btree (user_id);


--
-- Name: idx_ai_daily_scores_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_daily_scores_user_date ON public.ai_user_daily_scores USING btree (user_id, score_date);


--
-- Name: idx_ai_feedback_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_feedback_created_at ON public.ai_recommendation_feedback USING btree (created_at);


--
-- Name: idx_ai_feedback_recommendation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_feedback_recommendation ON public.ai_recommendation_feedback USING btree (recommendation_id);


--
-- Name: idx_ai_feedback_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_feedback_type ON public.ai_recommendation_feedback USING btree (feedback_type);


--
-- Name: idx_ai_feedback_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_feedback_user ON public.ai_recommendation_feedback USING btree (user_id);


--
-- Name: idx_ai_feedback_user_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_feedback_user_type ON public.ai_recommendation_feedback USING btree (user_id, feedback_type);


--
-- Name: idx_ai_predictions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_predictions_user_id ON public.ai_predictions USING btree (user_id);


--
-- Name: idx_ai_recommendations_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_recommendations_expires_at ON public.ai_recommendations USING btree (expires_at);


--
-- Name: idx_ai_recommendations_generated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_recommendations_generated_at ON public.ai_recommendations USING btree (generated_at);


--
-- Name: idx_ai_recommendations_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_recommendations_module ON public.ai_recommendations USING btree (module);


--
-- Name: idx_ai_recommendations_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_recommendations_priority ON public.ai_recommendations USING btree (priority);


--
-- Name: idx_ai_recommendations_rule; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_recommendations_rule ON public.ai_recommendations USING btree (rule_id);


--
-- Name: idx_ai_recommendations_severity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_recommendations_severity ON public.ai_recommendations USING btree (severity);


--
-- Name: idx_ai_recommendations_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_recommendations_status ON public.ai_recommendations USING btree (status);


--
-- Name: idx_ai_recommendations_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_recommendations_type ON public.ai_recommendations USING btree (recommendation_type);


--
-- Name: idx_ai_recommendations_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_recommendations_user ON public.ai_recommendations USING btree (user_id);


--
-- Name: idx_ai_recommendations_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_recommendations_user_id ON public.ai_recommendations USING btree (user_id);


--
-- Name: idx_ai_recommendations_user_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_recommendations_user_module ON public.ai_recommendations USING btree (user_id, module);


--
-- Name: idx_ai_recommendations_user_severity_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_recommendations_user_severity_status ON public.ai_recommendations USING btree (user_id, severity, status);


--
-- Name: idx_ai_recommendations_user_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_recommendations_user_status ON public.ai_recommendations USING btree (user_id, status);


--
-- Name: idx_ai_rules_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_rules_active ON public.ai_recommendation_rules USING btree (is_active);


--
-- Name: idx_ai_rules_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_rules_module ON public.ai_recommendation_rules USING btree (module);


--
-- Name: idx_ai_rules_module_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_rules_module_active ON public.ai_recommendation_rules USING btree (module, is_active);


--
-- Name: idx_ai_rules_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_rules_priority ON public.ai_recommendation_rules USING btree (priority);


--
-- Name: idx_ai_rules_severity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_rules_severity ON public.ai_recommendation_rules USING btree (severity);


--
-- Name: idx_ai_rules_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_rules_type ON public.ai_recommendation_rules USING btree (recommendation_type);


--
-- Name: idx_ai_user_daily_scores_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_user_daily_scores_user_id ON public.ai_user_daily_scores USING btree (user_id);


--
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: idx_automation_rules_user_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_automation_rules_user_active ON public.automation_rules USING btree (user_id, is_active);


--
-- Name: idx_error_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_error_logs_user_id ON public.error_logs USING btree (user_id);


--
-- Name: idx_finance_accounts_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_finance_accounts_user_id ON public.finance_accounts USING btree (user_id);


--
-- Name: idx_finance_budget_lines_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_finance_budget_lines_user_id ON public.finance_budget_lines USING btree (user_id);


--
-- Name: idx_finance_budgets_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_finance_budgets_user_id ON public.finance_budgets USING btree (user_id);


--
-- Name: idx_finance_transactions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_finance_transactions_user_id ON public.finance_transactions USING btree (user_id);


--
-- Name: idx_health_hydration_logs_log_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_hydration_logs_log_date ON public.health_hydration_logs USING btree (log_date);


--
-- Name: idx_health_hydration_logs_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_hydration_logs_user_date ON public.health_hydration_logs USING btree (user_id, log_date);


--
-- Name: idx_health_hydration_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_hydration_logs_user_id ON public.health_hydration_logs USING btree (user_id);


--
-- Name: idx_health_lab_tests_abnormal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_lab_tests_abnormal ON public.health_lab_tests USING btree (is_abnormal);


--
-- Name: idx_health_lab_tests_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_lab_tests_category ON public.health_lab_tests USING btree (category);


--
-- Name: idx_health_lab_tests_creatinine; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_lab_tests_creatinine ON public.health_lab_tests USING btree (creatinine);


--
-- Name: idx_health_lab_tests_egfr; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_lab_tests_egfr ON public.health_lab_tests USING btree (egfr);


--
-- Name: idx_health_lab_tests_is_abnormal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_lab_tests_is_abnormal ON public.health_lab_tests USING btree (is_abnormal);


--
-- Name: idx_health_lab_tests_phosphorus; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_lab_tests_phosphorus ON public.health_lab_tests USING btree (phosphorus);


--
-- Name: idx_health_lab_tests_potassium; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_lab_tests_potassium ON public.health_lab_tests USING btree (potassium);


--
-- Name: idx_health_lab_tests_user_category_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_lab_tests_user_category_date ON public.health_lab_tests USING btree (user_id, category, test_date);


--
-- Name: idx_health_lab_tests_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_lab_tests_user_date ON public.health_lab_tests USING btree (user_id, test_date);


--
-- Name: idx_health_lab_tests_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_lab_tests_user_id ON public.health_lab_tests USING btree (user_id);


--
-- Name: idx_health_meal_logs_meal_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_meal_logs_meal_date ON public.health_meal_logs USING btree (meal_date);


--
-- Name: idx_health_meal_logs_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_meal_logs_user_date ON public.health_meal_logs USING btree (user_id, meal_date);


--
-- Name: idx_health_meal_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_meal_logs_user_id ON public.health_meal_logs USING btree (user_id);


--
-- Name: idx_health_medication_dose_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_medication_dose_logs_user_id ON public.health_medication_dose_logs USING btree (user_id);


--
-- Name: idx_health_nutrition_logs_custom_food_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_nutrition_logs_custom_food_id ON public.health_nutrition_logs USING btree (custom_food_id);


--
-- Name: idx_health_nutrition_profiles_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_nutrition_profiles_user_id ON public.health_nutrition_profiles USING btree (user_id);


--
-- Name: idx_health_profile_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_profile_user_id ON public.health_profile USING btree (user_id);


--
-- Name: idx_health_step_log_user_date_desc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_step_log_user_date_desc ON public.health_step_log USING btree (user_id, log_date DESC);


--
-- Name: idx_health_step_log_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_step_log_user_id ON public.health_step_log USING btree (user_id);


--
-- Name: idx_health_weight_logs_log_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_weight_logs_log_date ON public.health_weight_logs USING btree (log_date);


--
-- Name: idx_health_weight_logs_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_weight_logs_user_date ON public.health_weight_logs USING btree (user_id, log_date);


--
-- Name: idx_health_weight_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_weight_logs_user_id ON public.health_weight_logs USING btree (user_id);


--
-- Name: idx_life_balance_scores_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_life_balance_scores_user_id ON public.life_balance_scores USING btree (user_id);


--
-- Name: idx_life_notifications_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_life_notifications_user_id ON public.life_notifications USING btree (user_id);


--
-- Name: idx_notification_preferences_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_preferences_user_id ON public.notification_preferences USING btree (user_id);


--
-- Name: idx_nutrition_custom_foods_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nutrition_custom_foods_user_id ON public.nutrition_custom_foods USING btree (user_id);


--
-- Name: idx_nutrition_food_aliases_alias_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nutrition_food_aliases_alias_trgm ON public.nutrition_food_aliases USING gin (alias_name public.gin_trgm_ops);


--
-- Name: idx_nutrition_food_servings_food_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nutrition_food_servings_food_id ON public.nutrition_food_servings USING btree (food_id);


--
-- Name: idx_nutrition_food_sources_food_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nutrition_food_sources_food_id ON public.nutrition_food_sources USING btree (food_id);


--
-- Name: idx_nutrition_foods_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nutrition_foods_active ON public.nutrition_foods USING btree (is_active);


--
-- Name: idx_nutrition_foods_brand_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nutrition_foods_brand_trgm ON public.nutrition_foods USING gin (brand_name public.gin_trgm_ops);


--
-- Name: idx_nutrition_foods_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nutrition_foods_category_id ON public.nutrition_foods USING btree (category_id);


--
-- Name: idx_nutrition_foods_ckd_friendly; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nutrition_foods_ckd_friendly ON public.nutrition_foods USING btree (is_ckd_friendly);


--
-- Name: idx_nutrition_foods_low_phosphorus; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nutrition_foods_low_phosphorus ON public.nutrition_foods USING btree (is_low_phosphorus);


--
-- Name: idx_nutrition_foods_low_potassium; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nutrition_foods_low_potassium ON public.nutrition_foods USING btree (is_low_potassium);


--
-- Name: idx_nutrition_foods_low_sodium; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nutrition_foods_low_sodium ON public.nutrition_foods USING btree (is_low_sodium);


--
-- Name: idx_nutrition_foods_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nutrition_foods_name_trgm ON public.nutrition_foods USING gin (name public.gin_trgm_ops);


--
-- Name: idx_nutrition_foods_warning_level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nutrition_foods_warning_level ON public.nutrition_foods USING btree (ckd_warning_level);


--
-- Name: idx_project_status_updates_milestone_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_project_status_updates_milestone_id ON public.project_status_updates USING btree (milestone_id);


--
-- Name: idx_project_status_updates_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_project_status_updates_task_id ON public.project_status_updates USING btree (task_id);


--
-- Name: idx_project_tasks_due_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_project_tasks_due_date ON public.project_tasks USING btree (due_date);


--
-- Name: idx_project_tasks_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_project_tasks_priority ON public.project_tasks USING btree (priority);


--
-- Name: idx_project_tasks_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_project_tasks_project_id ON public.project_tasks USING btree (project_id);


--
-- Name: idx_project_tasks_project_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_project_tasks_project_status ON public.project_tasks USING btree (project_id, status);


--
-- Name: idx_project_tasks_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_project_tasks_status ON public.project_tasks USING btree (status);


--
-- Name: idx_project_tasks_user_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_project_tasks_user_status ON public.project_tasks USING btree (user_id, status);


--
-- Name: idx_projects_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_projects_priority ON public.projects USING btree (priority);


--
-- Name: idx_projects_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_projects_status ON public.projects USING btree (status);


--
-- Name: idx_projects_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_projects_user_id ON public.projects USING btree (user_id);


--
-- Name: idx_projects_user_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_projects_user_status ON public.projects USING btree (user_id, status);


--
-- Name: idx_step82_ai_recommendations_user_module_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_step82_ai_recommendations_user_module_status ON public.ai_recommendations USING btree (user_id, module, status);


--
-- Name: idx_step82_finance_accounts_user_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_step82_finance_accounts_user_active ON public.finance_accounts USING btree (user_id, is_active);


--
-- Name: idx_step82_finance_budgets_user_month_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_step82_finance_budgets_user_month_active ON public.finance_budgets USING btree (user_id, budget_month, is_active);


--
-- Name: idx_step82_finance_transactions_user_account_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_step82_finance_transactions_user_account_date ON public.finance_transactions USING btree (user_id, account_id, transaction_date);


--
-- Name: idx_step82_finance_transactions_user_type_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_step82_finance_transactions_user_type_date ON public.finance_transactions USING btree (user_id, transaction_type, transaction_date);


--
-- Name: idx_step82_health_alerts_user_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_step82_health_alerts_user_status ON public.health_alerts USING btree (user_id, status);


--
-- Name: idx_step82_health_hydration_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_step82_health_hydration_user_date ON public.health_hydration_logs USING btree (user_id, log_date);


--
-- Name: idx_step82_health_lab_tests_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_step82_health_lab_tests_user_date ON public.health_lab_tests USING btree (user_id, test_date);


--
-- Name: idx_step82_health_step_log_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_step82_health_step_log_user_date ON public.health_step_log USING btree (user_id, log_date);


--
-- Name: idx_step82_health_weight_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_step82_health_weight_user_date ON public.health_weight_logs USING btree (user_id, log_date);


--
-- Name: idx_step82_productivity_calendar_user_start_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_step82_productivity_calendar_user_start_status ON public.productivity_calendar_events USING btree (user_id, start_time, status);


--
-- Name: idx_step82_productivity_goals_user_status_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_step82_productivity_goals_user_status_target ON public.productivity_goals USING btree (user_id, status, target_date);


--
-- Name: idx_step82_productivity_habits_user_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_step82_productivity_habits_user_status ON public.productivity_habits USING btree (user_id, status);


--
-- Name: idx_step82_productivity_tasks_user_status_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_step82_productivity_tasks_user_status_due ON public.productivity_tasks USING btree (user_id, status, due_date);


--
-- Name: idx_step82_project_tasks_user_status_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_step82_project_tasks_user_status_due ON public.project_tasks USING btree (user_id, status, due_date);


--
-- Name: idx_step82_projects_user_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_step82_projects_user_status ON public.projects USING btree (user_id, status);


--
-- Name: idx_subscription_usage_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscription_usage_user_id ON public.subscription_usage USING btree (user_id);


--
-- Name: idx_subscriptions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscriptions_user_id ON public.subscriptions USING btree (user_id);


--
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: life_balance_scores_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX life_balance_scores_status_index ON public.life_balance_scores USING btree (status);


--
-- Name: life_balance_scores_user_id_overall_score_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX life_balance_scores_user_id_overall_score_index ON public.life_balance_scores USING btree (user_id, overall_score);


--
-- Name: life_balance_scores_user_id_target_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX life_balance_scores_user_id_target_date_index ON public.life_balance_scores USING btree (user_id, target_date);


--
-- Name: life_notifications_is_read_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX life_notifications_is_read_index ON public.life_notifications USING btree (is_read);


--
-- Name: life_notifications_notification_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX life_notifications_notification_type_index ON public.life_notifications USING btree (notification_type);


--
-- Name: life_notifications_scheduled_for_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX life_notifications_scheduled_for_index ON public.life_notifications USING btree (scheduled_for);


--
-- Name: life_notifications_severity_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX life_notifications_severity_index ON public.life_notifications USING btree (severity);


--
-- Name: life_notifications_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX life_notifications_user_id_index ON public.life_notifications USING btree (user_id);


--
-- Name: life_notifications_user_id_is_read_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX life_notifications_user_id_is_read_index ON public.life_notifications USING btree (user_id, is_read);


--
-- Name: model_has_permissions_model_id_model_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_has_permissions_model_id_model_type_index ON public.model_has_permissions USING btree (model_id, model_type);


--
-- Name: model_has_roles_model_id_model_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_has_roles_model_id_model_type_index ON public.model_has_roles USING btree (model_id, model_type);


--
-- Name: notification_preferences_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notification_preferences_user_id_index ON public.notification_preferences USING btree (user_id);


--
-- Name: nutrition_custom_foods_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nutrition_custom_foods_category_index ON public.nutrition_custom_foods USING btree (category);


--
-- Name: nutrition_custom_foods_is_global_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nutrition_custom_foods_is_global_index ON public.nutrition_custom_foods USING btree (is_global);


--
-- Name: nutrition_custom_foods_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nutrition_custom_foods_name_index ON public.nutrition_custom_foods USING btree (name);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: productivity_calendar_events_user_id_event_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX productivity_calendar_events_user_id_event_type_index ON public.productivity_calendar_events USING btree (user_id, event_type);


--
-- Name: productivity_calendar_events_user_id_start_time_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX productivity_calendar_events_user_id_start_time_index ON public.productivity_calendar_events USING btree (user_id, start_time);


--
-- Name: productivity_calendar_events_user_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX productivity_calendar_events_user_id_status_index ON public.productivity_calendar_events USING btree (user_id, status);


--
-- Name: productivity_goals_user_id_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX productivity_goals_user_id_category_index ON public.productivity_goals USING btree (user_id, category);


--
-- Name: productivity_goals_user_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX productivity_goals_user_id_status_index ON public.productivity_goals USING btree (user_id, status);


--
-- Name: productivity_goals_user_id_target_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX productivity_goals_user_id_target_date_index ON public.productivity_goals USING btree (user_id, target_date);


--
-- Name: productivity_habit_check_ins_user_id_check_in_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX productivity_habit_check_ins_user_id_check_in_date_index ON public.productivity_habit_check_ins USING btree (user_id, check_in_date);


--
-- Name: productivity_habit_check_ins_user_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX productivity_habit_check_ins_user_id_status_index ON public.productivity_habit_check_ins USING btree (user_id, status);


--
-- Name: productivity_habits_user_id_frequency_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX productivity_habits_user_id_frequency_index ON public.productivity_habits USING btree (user_id, frequency);


--
-- Name: productivity_habits_user_id_last_completed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX productivity_habits_user_id_last_completed_at_index ON public.productivity_habits USING btree (user_id, last_completed_at);


--
-- Name: productivity_habits_user_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX productivity_habits_user_id_status_index ON public.productivity_habits USING btree (user_id, status);


--
-- Name: productivity_tasks_user_id_due_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX productivity_tasks_user_id_due_date_index ON public.productivity_tasks USING btree (user_id, due_date);


--
-- Name: productivity_tasks_user_id_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX productivity_tasks_user_id_priority_index ON public.productivity_tasks USING btree (user_id, priority);


--
-- Name: productivity_tasks_user_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX productivity_tasks_user_id_status_index ON public.productivity_tasks USING btree (user_id, status);


--
-- Name: project_milestones_project_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_milestones_project_id_status_index ON public.project_milestones USING btree (project_id, status);


--
-- Name: project_status_updates_project_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_status_updates_project_id_created_at_index ON public.project_status_updates USING btree (project_id, created_at);


--
-- Name: project_status_updates_project_id_update_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_status_updates_project_id_update_type_index ON public.project_status_updates USING btree (project_id, update_type);


--
-- Name: project_tasks_due_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_tasks_due_date_index ON public.project_tasks USING btree (due_date);


--
-- Name: project_tasks_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_tasks_priority_index ON public.project_tasks USING btree (priority);


--
-- Name: project_tasks_project_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_tasks_project_id_status_index ON public.project_tasks USING btree (project_id, status);


--
-- Name: project_tasks_user_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_tasks_user_id_status_index ON public.project_tasks USING btree (user_id, status);


--
-- Name: projects_start_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX projects_start_date_index ON public.projects USING btree (start_date);


--
-- Name: projects_target_end_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX projects_target_end_date_index ON public.projects USING btree (target_end_date);


--
-- Name: projects_user_id_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX projects_user_id_priority_index ON public.projects USING btree (user_id, priority);


--
-- Name: projects_user_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX projects_user_id_status_index ON public.projects USING btree (user_id, status);


--
-- Name: subscription_usage_subscription_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subscription_usage_subscription_id_index ON public.subscription_usage USING btree (subscription_id);


--
-- Name: subscription_usage_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subscription_usage_user_id_index ON public.subscription_usage USING btree (user_id);


--
-- Name: subscriptions_plan_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subscriptions_plan_id_index ON public.subscriptions USING btree (plan_id);


--
-- Name: subscriptions_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subscriptions_status_index ON public.subscriptions USING btree (status);


--
-- Name: subscriptions_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subscriptions_user_id_index ON public.subscriptions USING btree (user_id);


--
-- Name: system_monitoring_logs_checked_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_monitoring_logs_checked_at_index ON public.system_monitoring_logs USING btree (checked_at);


--
-- Name: system_monitoring_logs_service_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_monitoring_logs_service_name_index ON public.system_monitoring_logs USING btree (service_name);


--
-- Name: system_monitoring_logs_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_monitoring_logs_status_index ON public.system_monitoring_logs USING btree (status);


--
-- Name: tasks_due_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_due_date_index ON public.tasks USING btree (due_date);


--
-- Name: tasks_user_id_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_user_id_priority_index ON public.tasks USING btree (user_id, priority);


--
-- Name: tasks_user_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_user_id_status_index ON public.tasks USING btree (user_id, status);


--
-- Name: users_role_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_role_is_active_index ON public.users USING btree (role, is_active);


--
-- Name: health_meal_log health_meal_log_user_id_fkey; Type: FK CONSTRAINT; Schema: nix_life_os; Owner: -
--

ALTER TABLE ONLY nix_life_os.health_meal_log
    ADD CONSTRAINT health_meal_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES nix_life_os.app_user(user_id) ON DELETE CASCADE;


--
-- Name: health_step_log health_step_log_user_id_fkey; Type: FK CONSTRAINT; Schema: nix_life_os; Owner: -
--

ALTER TABLE ONLY nix_life_os.health_step_log
    ADD CONSTRAINT health_step_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES nix_life_os.app_user(user_id) ON DELETE CASCADE;


--
-- Name: ai_alerts ai_alerts_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_alerts
    ADD CONSTRAINT ai_alerts_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_insights ai_insights_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_insights
    ADD CONSTRAINT ai_insights_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_predictions ai_predictions_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_predictions
    ADD CONSTRAINT ai_predictions_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_recommendation_feedback ai_recommendation_feedback_recommendation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_recommendation_feedback
    ADD CONSTRAINT ai_recommendation_feedback_recommendation_id_foreign FOREIGN KEY (recommendation_id) REFERENCES public.ai_recommendations(id) ON DELETE CASCADE;


--
-- Name: ai_recommendation_feedback ai_recommendation_feedback_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_recommendation_feedback
    ADD CONSTRAINT ai_recommendation_feedback_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_recommendations ai_recommendations_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_recommendations
    ADD CONSTRAINT ai_recommendations_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_recommendations ai_recommendations_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_recommendations
    ADD CONSTRAINT ai_recommendations_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_reports ai_reports_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_reports
    ADD CONSTRAINT ai_reports_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_user_daily_scores ai_user_daily_scores_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_user_daily_scores
    ADD CONSTRAINT ai_user_daily_scores_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_user_daily_scores ai_user_daily_scores_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_user_daily_scores
    ADD CONSTRAINT ai_user_daily_scores_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: automation_rules automation_rules_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_rules
    ADD CONSTRAINT automation_rules_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: automation_trigger_logs automation_trigger_logs_automation_rule_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_trigger_logs
    ADD CONSTRAINT automation_trigger_logs_automation_rule_id_foreign FOREIGN KEY (automation_rule_id) REFERENCES public.automation_rules(id) ON DELETE CASCADE;


--
-- Name: automation_trigger_logs automation_trigger_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_trigger_logs
    ADD CONSTRAINT automation_trigger_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: error_logs error_logs_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_logs
    ADD CONSTRAINT error_logs_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: finance_accounts finance_accounts_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_accounts
    ADD CONSTRAINT finance_accounts_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: finance_budget_lines finance_budget_lines_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_budget_lines
    ADD CONSTRAINT finance_budget_lines_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: finance_budgets finance_budgets_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_budgets
    ADD CONSTRAINT finance_budgets_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: finance_transactions finance_transactions_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_transactions
    ADD CONSTRAINT finance_transactions_account_id_foreign FOREIGN KEY (account_id) REFERENCES public.finance_accounts(id) ON DELETE SET NULL;


--
-- Name: finance_transactions finance_transactions_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_transactions
    ADD CONSTRAINT finance_transactions_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_recommendations fk_ai_recommendations_rule; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_recommendations
    ADD CONSTRAINT fk_ai_recommendations_rule FOREIGN KEY (rule_id) REFERENCES public.ai_recommendation_rules(id) ON DELETE SET NULL;


--
-- Name: health_alerts health_alerts_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_alerts
    ADD CONSTRAINT health_alerts_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: health_food_items health_food_items_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_food_items
    ADD CONSTRAINT health_food_items_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: health_hydration_logs health_hydration_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_hydration_logs
    ADD CONSTRAINT health_hydration_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: health_lab_tests health_lab_tests_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_lab_tests
    ADD CONSTRAINT health_lab_tests_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: health_meal_log_items health_meal_log_items_food_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_meal_log_items
    ADD CONSTRAINT health_meal_log_items_food_item_id_foreign FOREIGN KEY (food_item_id) REFERENCES public.health_food_items(id) ON DELETE RESTRICT;


--
-- Name: health_meal_log_items health_meal_log_items_meal_log_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_meal_log_items
    ADD CONSTRAINT health_meal_log_items_meal_log_id_foreign FOREIGN KEY (meal_log_id) REFERENCES public.health_meal_logs(id) ON DELETE CASCADE;


--
-- Name: health_meal_logs health_meal_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_meal_logs
    ADD CONSTRAINT health_meal_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: health_medication_dose_logs health_medication_dose_logs_medication_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_medication_dose_logs
    ADD CONSTRAINT health_medication_dose_logs_medication_id_foreign FOREIGN KEY (medication_id) REFERENCES public.health_medications(id) ON DELETE CASCADE;


--
-- Name: health_medication_dose_logs health_medication_dose_logs_reminder_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_medication_dose_logs
    ADD CONSTRAINT health_medication_dose_logs_reminder_id_foreign FOREIGN KEY (reminder_id) REFERENCES public.health_medication_reminders(id) ON DELETE SET NULL;


--
-- Name: health_medication_dose_logs health_medication_dose_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_medication_dose_logs
    ADD CONSTRAINT health_medication_dose_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: health_medication_dose_logs health_medication_dose_logs_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_medication_dose_logs
    ADD CONSTRAINT health_medication_dose_logs_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: health_medication_reminders health_medication_reminders_medication_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_medication_reminders
    ADD CONSTRAINT health_medication_reminders_medication_id_foreign FOREIGN KEY (medication_id) REFERENCES public.health_medications(id) ON DELETE CASCADE;


--
-- Name: health_medication_reminders health_medication_reminders_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_medication_reminders
    ADD CONSTRAINT health_medication_reminders_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: health_medications health_medications_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_medications
    ADD CONSTRAINT health_medications_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: health_mood_logs health_mood_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_mood_logs
    ADD CONSTRAINT health_mood_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: health_nutrition_logs health_nutrition_logs_custom_food_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_nutrition_logs
    ADD CONSTRAINT health_nutrition_logs_custom_food_id_foreign FOREIGN KEY (custom_food_id) REFERENCES public.nutrition_custom_foods(id) ON DELETE SET NULL;


--
-- Name: health_nutrition_logs health_nutrition_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_nutrition_logs
    ADD CONSTRAINT health_nutrition_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: health_nutrition_profiles health_nutrition_profiles_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_nutrition_profiles
    ADD CONSTRAINT health_nutrition_profiles_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: health_nutrition_profiles health_nutrition_profiles_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_nutrition_profiles
    ADD CONSTRAINT health_nutrition_profiles_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: health_profile health_profile_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_profile
    ADD CONSTRAINT health_profile_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: health_profile health_profile_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_profile
    ADD CONSTRAINT health_profile_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: health_sleep_logs health_sleep_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_sleep_logs
    ADD CONSTRAINT health_sleep_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: health_step_log health_step_log_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_step_log
    ADD CONSTRAINT health_step_log_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: health_step_log health_step_log_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_step_log
    ADD CONSTRAINT health_step_log_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: health_weight_logs health_weight_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_weight_logs
    ADD CONSTRAINT health_weight_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: health_weight_logs health_weight_logs_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_weight_logs
    ADD CONSTRAINT health_weight_logs_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: life_balance_scores life_balance_scores_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.life_balance_scores
    ADD CONSTRAINT life_balance_scores_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: life_notifications life_notifications_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.life_notifications
    ADD CONSTRAINT life_notifications_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: model_has_permissions model_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: model_has_roles model_has_roles_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: notification_preferences notification_preferences_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: nutrition_custom_foods nutrition_custom_foods_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_custom_foods
    ADD CONSTRAINT nutrition_custom_foods_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: nutrition_custom_foods nutrition_custom_foods_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_custom_foods
    ADD CONSTRAINT nutrition_custom_foods_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: nutrition_food_aliases nutrition_food_aliases_food_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_food_aliases
    ADD CONSTRAINT nutrition_food_aliases_food_id_foreign FOREIGN KEY (food_id) REFERENCES public.nutrition_foods(id) ON DELETE CASCADE;


--
-- Name: nutrition_food_servings nutrition_food_servings_food_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_food_servings
    ADD CONSTRAINT nutrition_food_servings_food_id_foreign FOREIGN KEY (food_id) REFERENCES public.nutrition_foods(id) ON DELETE CASCADE;


--
-- Name: nutrition_food_sources nutrition_food_sources_food_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_food_sources
    ADD CONSTRAINT nutrition_food_sources_food_id_foreign FOREIGN KEY (food_id) REFERENCES public.nutrition_foods(id) ON DELETE CASCADE;


--
-- Name: nutrition_foods nutrition_foods_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_foods
    ADD CONSTRAINT nutrition_foods_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.nutrition_food_categories(id) ON DELETE SET NULL;


--
-- Name: productivity_calendar_events productivity_calendar_events_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.productivity_calendar_events
    ADD CONSTRAINT productivity_calendar_events_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: productivity_goals productivity_goals_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.productivity_goals
    ADD CONSTRAINT productivity_goals_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: productivity_habit_check_ins productivity_habit_check_ins_habit_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.productivity_habit_check_ins
    ADD CONSTRAINT productivity_habit_check_ins_habit_id_foreign FOREIGN KEY (habit_id) REFERENCES public.productivity_habits(id) ON DELETE CASCADE;


--
-- Name: productivity_habit_check_ins productivity_habit_check_ins_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.productivity_habit_check_ins
    ADD CONSTRAINT productivity_habit_check_ins_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: productivity_habits productivity_habits_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.productivity_habits
    ADD CONSTRAINT productivity_habits_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: productivity_tasks productivity_tasks_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.productivity_tasks
    ADD CONSTRAINT productivity_tasks_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: project_milestones project_milestones_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_milestones
    ADD CONSTRAINT project_milestones_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_status_updates project_status_updates_milestone_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_status_updates
    ADD CONSTRAINT project_status_updates_milestone_id_foreign FOREIGN KEY (milestone_id) REFERENCES public.project_milestones(id) ON DELETE SET NULL;


--
-- Name: project_status_updates project_status_updates_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_status_updates
    ADD CONSTRAINT project_status_updates_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_status_updates project_status_updates_task_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_status_updates
    ADD CONSTRAINT project_status_updates_task_id_foreign FOREIGN KEY (task_id) REFERENCES public.project_tasks(id) ON DELETE SET NULL;


--
-- Name: project_tasks project_tasks_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT project_tasks_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_tasks project_tasks_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT project_tasks_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: projects projects_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: role_has_permissions role_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_has_permissions role_has_permissions_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: subscription_usage subscription_usage_subscription_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_usage
    ADD CONSTRAINT subscription_usage_subscription_id_foreign FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON DELETE CASCADE;


--
-- Name: subscription_usage subscription_usage_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_usage
    ADD CONSTRAINT subscription_usage_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: subscription_usage subscription_usage_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_usage
    ADD CONSTRAINT subscription_usage_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_plan_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_plan_id_foreign FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_user_id_foreign_step80; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_foreign_step80 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict uF9N8XyiTwnqAJX5ZxPB2u2rgNcEedvyumKeZrK5l8nNISbKpCAK0KlJ45t9O38

