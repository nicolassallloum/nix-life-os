# STEP 84 — PostgreSQL Query Optimization Export

This archive contains files needed to review and optimize PostgreSQL query performance for Nix Life OS.

## Included Areas

- Laravel backend models, controllers, services, repositories, actions
- API route definitions
- Database migrations, seeders, factories
- PostgreSQL schema-only dump
- Table/index size reports
- Index usage reports
- Sequential scan reports
- Foreign key and column metadata
- PostgreSQL settings
- pg_stat_statements output if available
- Laravel logs
- Docker/Nginx/PHP-FPM configuration
- Frontend API usage files

## Review Goals

1. Identify slow dashboard queries.
2. Detect missing indexes.
3. Detect unused or duplicate indexes.
4. Optimize finance summary queries.
5. Optimize health summary queries.
6. Optimize project progress queries.
7. Optimize productivity and AI insight queries.
8. Recommend EXPLAIN ANALYZE commands.
9. Provide Laravel query rewrites.
10. Provide final PostgreSQL optimization checklist.

