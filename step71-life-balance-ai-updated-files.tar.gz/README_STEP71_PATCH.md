# STEP 71 Life Balance AI Patch

## Files included

- backend/routes/api.php
- backend/app/Http/Controllers/Api/V1/LifeBalanceAiRecommendationController.php
- backend/app/Services/LifeBalanceAiRecommendationService.php
- frontend/src/services/lifeBalanceService.js
- frontend/src/services/lifeBalanceService.ts
- frontend/src/views/life-balance/LifeBalanceView.vue
- frontend/src/router/index.js
- frontend/src/router/index.ts
- install_step71_life_balance_ai_patch.sh

## What this patch adds

- Adds `/api/v1/life-balance/ai-recommendations`
- Adds aliases:
  - `/api/v1/life-balance/recommendations`
  - `/api/v1/ai/life-balance/recommendations`
- Generates Life Balance AI recommendations from finance, health, projects, productivity, habits, goals, tasks, and calendar data.
- Uses `start_time` for calendar checks instead of the missing `event_date` column.
- Updates frontend Life Balance route to use `frontend/src/views/life-balance/LifeBalanceView.vue`.
- Adds frontend `lifeBalanceService`.
- Displays structured recommendation cards with category and priority badges.

## Install

From extracted patch folder:

```bash
chmod +x install_step71_life_balance_ai_patch.sh
./install_step71_life_balance_ai_patch.sh
```

## Test

```bash
cd /u01/nix-life-os

TOKEN=$(curl -s -X POST "http://127.0.0.1:8000/api/v1/auth/login" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -d '{"email":"test@nixlifeos.com","password":"password"}' | jq -r '.data.token')

curl -s "http://127.0.0.1:8000/api/v1/life-balance/ai-recommendations" \
  -H "Accept: application/json" \
  -H "Authorization: Bearer $TOKEN" | jq .
```

Expected: HTTP 200 with `success`, `score`, `status`, `categories`, and `recommendations`.
