#!/usr/bin/env bash
set -e

BASE_DIR="/u01/nix-life-os"
PATCH_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKUP_DIR="$BASE_DIR/backups/step71-life-balance-ai-$(date +%Y%m%d_%H%M%S)"

mkdir -p "$BACKUP_DIR"
cd "$BASE_DIR"

copy_file() {
  local relative_path="$1"
  local source_file="$PATCH_DIR/$relative_path"
  local target_file="$BASE_DIR/$relative_path"

  if [ ! -f "$source_file" ]; then
    echo "SKIP missing patch file: $relative_path"
    return
  fi

  if [ -f "$target_file" ]; then
    mkdir -p "$BACKUP_DIR/$(dirname "$relative_path")"
    cp "$target_file" "$BACKUP_DIR/$relative_path"
    echo "BACKUP: $relative_path"
  fi

  mkdir -p "$(dirname "$target_file")"
  cp "$source_file" "$target_file"
  echo "UPDATED: $relative_path"
}

copy_file "backend/routes/api.php"
copy_file "backend/app/Http/Controllers/Api/V1/LifeBalanceAiRecommendationController.php"
copy_file "backend/app/Services/LifeBalanceAiRecommendationService.php"
copy_file "frontend/src/services/lifeBalanceService.js"
copy_file "frontend/src/services/lifeBalanceService.ts"
copy_file "frontend/src/views/life-balance/LifeBalanceView.vue"
copy_file "frontend/src/router/index.js"
copy_file "frontend/src/router/index.ts"

echo ""
echo "Running Laravel optimization clear..."
docker exec nixlifeos-backend sh -lc "php artisan optimize:clear" || true

echo ""
echo "Checking updated PHP syntax inside backend container..."
docker exec nixlifeos-backend sh -lc "php -l app/Http/Controllers/Api/V1/LifeBalanceAiRecommendationController.php && php -l app/Services/LifeBalanceAiRecommendationService.php"

echo ""
echo "Checking updated route registration..."
docker exec nixlifeos-backend sh -lc "php artisan route:list | grep -E 'life-balance|ai/recommendations' || true"

echo ""
echo "STEP 71 patch installed. Backup saved to: $BACKUP_DIR"
