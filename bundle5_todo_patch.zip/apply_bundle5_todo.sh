#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="${1:-/home/nix/u01/nix-life-os}"
PATCH_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/bundle5_todo_patch"

if [[ ! -d "$PROJECT_ROOT" ]]; then
  echo "Project root not found: $PROJECT_ROOT" >&2
  echo "Usage: bash apply_bundle5_todo.sh /path/to/nix-life-os" >&2
  exit 1
fi

if [[ ! -f "$PROJECT_ROOT/artisan" ]]; then
  echo "This does not look like a Laravel project root: $PROJECT_ROOT" >&2
  exit 1
fi

cp -R "$PATCH_ROOT/database" "$PROJECT_ROOT/"
cp -R "$PATCH_ROOT/app" "$PROJECT_ROOT/"
cp -R "$PATCH_ROOT/resources" "$PROJECT_ROOT/"
mkdir -p "$PROJECT_ROOT/docs"
cp -R "$PATCH_ROOT/docs"/* "$PROJECT_ROOT/docs/"
cp "$PATCH_ROOT/README_BUNDLE5.md" "$PROJECT_ROOT/README_BUNDLE5.md"

cat <<'MSG'
Bundle 5 files copied.

Manual merge still required:
1. Open docs/routes_api_bundle5_snippet.php and merge the route block into routes/api.php.
2. If duplicate routes already exist, merge the methods/response fields into existing controllers instead.
3. Add docs/router_bundle5_snippet.js to your Vue router if needed.
4. Run:
   npm install vuedraggable@next sortablejs
   php artisan migrate
   php artisan route:clear
   php artisan config:clear
   php artisan test
   npm run build
   git add .
   git commit -m "Implement Bundle 5 task organization drag drop ordering and points system"
MSG
